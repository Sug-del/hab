import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import Image from "next/image"

interface SocialLink {
  id: string
  platform: string
  url: string
}

interface ProfileData {
  fullName: string
  nickname: string
  bio: string
  emoji: string
  profileImage: string
  socialLinks: SocialLink[]
}

interface ProfilePreviewProps {
  data: ProfileData
}

export function ProfilePreview({ data }: ProfilePreviewProps) {
  return (
    <Card className="max-w-md mx-auto bg-white shadow-lg">
      <CardContent className="p-8 text-center">
        {/* Profile Image */}
        <div className="mb-6">
          {data.profileImage ? (
            <Image
              src={data.profileImage || "/placeholder.svg"}
              alt={data.fullName}
              width={120}
              height={120}
              className="w-30 h-30 rounded-full mx-auto object-cover border-4 border-gray-100"
            />
          ) : (
            <div className="w-30 h-30 rounded-full mx-auto bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center text-4xl text-white">
              {data.emoji || "😊"}
            </div>
          )}
        </div>

        {/* Name and Nickname */}
        <div className="mb-4">
          <h1 className="text-2xl font-bold text-gray-900 mb-1">{data.fullName || "Votre nom"}</h1>
          {data.nickname && <p className="text-gray-600">{data.nickname}</p>}
        </div>

        {/* Bio */}
        {data.bio && <p className="text-gray-700 mb-6 leading-relaxed">{data.bio}</p>}

        {/* Social Links */}
        {data.socialLinks.length > 0 && (
          <div className="space-y-3">
            {data.socialLinks.map((link) => (
              <Button key={link.id} variant="outline" className="w-full justify-between hover:bg-gray-50" asChild>
                <a href={link.url} target="_blank" rel="noopener noreferrer">
                  <span>{link.platform}</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </Button>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!data.fullName && !data.bio && data.socialLinks.length === 0 && (
          <div className="text-gray-400 py-8">
            <p>Votre aperçu apparaîtra ici</p>
            <p className="text-sm mt-2">Commencez par remplir vos informations</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
