"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Plus, FileText, Zap } from "lucide-react"
import Link from "next/link"

export function QuickActions() {
  return (
    <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0 mb-8">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold mb-2">Actions rapides</h2>
            <p className="text-blue-100">Que souhaitez-vous créer aujourd'hui ?</p>
          </div>

          <div className="flex items-center gap-3">
            <Link href="/biens/nouveau">
              <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-0">
                <Plus className="w-4 h-4 mr-2" />
                Nouveau bien
              </Button>
            </Link>

            <Link href="/contenu/nouveau">
              <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-0">
                <FileText className="w-4 h-4 mr-2" />
                Générer contenu
              </Button>
            </Link>

            <Link href="/workflows/nouveau">
              <Button variant="secondary" className="bg-white text-blue-600 hover:bg-slate-50">
                <Zap className="w-4 h-4 mr-2" />
                Lancer workflow
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
