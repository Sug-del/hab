"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"

export function PromptInput() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Redirect to generator with prompt
    const encodedPrompt = encodeURIComponent(prompt)
    router.push(`/generateur?prompt=${encodedPrompt}`)
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
      <div className="relative">
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Décrivez l'application que vous souhaitez créer... (ex: Une page d'accueil pour un restaurant avec menu et réservations)"
          className="min-h-[120px] text-lg p-6 pr-20 border-2 border-slate-200 focus:border-indigo-500 rounded-2xl bg-white/80 backdrop-blur-sm resize-none shadow-lg"
          disabled={isLoading}
        />
        <Button
          type="submit"
          disabled={!prompt.trim() || isLoading}
          className="absolute bottom-4 right-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl px-6 py-3"
        >
          {isLoading ? (
            <>
              <Sparkles className="w-5 h-5 mr-2 animate-spin" />
              Génération...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 mr-2" />
              Générer
              <ArrowRight className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </div>

      <div className="flex items-center justify-center mt-4 text-sm text-slate-500">
        <span>✨ Gratuit • Aucune inscription requise • Résultat en 30 secondes</span>
      </div>
    </form>
  )
}
