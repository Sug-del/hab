import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY!)

export const sendWelcomeEmail = async (email: string, name: string) => {
  return await resend.emails.send({
    from: "ImmoContent <noreply@immocontent.fr>",
    to: email,
    subject: "Bienvenue sur ImmoContent ! 🏠",
    html: `
      <h1>Bienvenue ${name} !</h1>
      <p>Votre compte ImmoContent est prêt.</p>
      <p>Commencez dès maintenant à générer du contenu immobilier professionnel.</p>
      <a href="${process.env.NEXT_PUBLIC_BASE_URL}/dashboard" 
         style="background: #3B82F6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
        Accéder au dashboard
      </a>
    `,
  })
}

export const sendPaymentConfirmation = async (email: string, plan: string, amount: number) => {
  return await resend.emails.send({
    from: "ImmoContent <billing@immocontent.fr>",
    to: email,
    subject: `Paiement confirmé - Plan ${plan}`,
    html: `
      <h1>Paiement confirmé ✅</h1>
      <p>Votre abonnement au plan ${plan} est maintenant actif.</p>
      <p>Montant : ${amount}€</p>
      <p>Vous avez maintenant accès à toutes les fonctionnalités premium.</p>
    `,
  })
}
