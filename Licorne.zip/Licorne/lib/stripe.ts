import Stripe from "stripe"

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

export const PLANS = {
  starter: {
    name: "Starter",
    price: 9,
    priceId: process.env.STRIPE_STARTER_PRICE_ID!,
    features: ["50 contenus par mois", "Tous les générateurs", "Calendrier éditorial", "Support email"],
    contentLimit: 50,
  },
  pro: {
    name: "Pro",
    price: 29,
    priceId: process.env.STRIPE_PRO_PRICE_ID!,
    features: ["Contenus illimités", "Planification automatique", "Statistiques avancées", "Support prioritaire"],
    contentLimit: 999999,
  },
  agence: {
    name: "Agence",
    price: 99,
    priceId: process.env.STRIPE_AGENCE_PRICE_ID!,
    features: ["Tout du plan Pro", "5 utilisateurs", "Gestion d'équipe", "API access", "Support téléphonique"],
    contentLimit: 999999,
  },
} as const

export type PlanType = keyof typeof PLANS
