import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types pour TypeScript
export type User = {
  id: string
  email: string
  name: string
  subscription_type: "starter" | "pro" | "agence"
  content_generated: number
  content_limit: number
  stripe_customer_id?: string
  created_at: string
}
