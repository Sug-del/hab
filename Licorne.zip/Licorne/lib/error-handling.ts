// Gestion d'erreurs robuste
export class AIServiceError extends Error {
  constructor(
    message: string,
    public code: string,
    public retryable = false,
  ) {
    super(message)
    this.name = "AIServiceError"
  }
}

export const withRetry = async <T>(\
  operation: () => Promise<T>,\
  maxRetries: number = 3,\
  delay: number = 1000\
)
: Promise<T> =>
{
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      if (i === maxRetries - 1) throw error
      if (error instanceof AIServiceError && !error.retryable) throw error

      await new Promise((resolve) => setTimeout(resolve, delay * Math.pow(2, i)))
    }
  }
  throw new AIServiceError("Max retries exceeded", "MAX_RETRIES_EXCEEDED", false)
}

export const handleAIError = (error: any): AIServiceError => {
  if (error.status === 429) {
    return new AIServiceError("Rate limit exceeded", "RATE_LIMIT", true)
  }
  if (error.status >= 500) {
    return new AIServiceError("AI service unavailable", "SERVICE_DOWN", true)
  }
  return new AIServiceError("AI generation failed", "GENERATION_ERROR", false)
}
