import { Resend } from "resend"
import { createClient } from "@supabase/supabase-js"

const resend = new Resend(process.env.RESEND_API_KEY!)
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Templates d'emails professionnels
export const EMAIL_TEMPLATES = {
  welcome: {
    subject: "🏠 Bienvenue sur ImmoContent - Votre assistant IA immobilier",
    html: (name: string, loginUrl: string) => `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Bienvenue sur ImmoContent</title>
        </head>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <img src="${process.env.NEXT_PUBLIC_BASE_URL}/logo.png" alt="ImmoContent" style="height: 60px;">
          </div>
          
          <h1 style="color: #1f2937; text-align: center;">Bienvenue ${name} ! 🎉</h1>
          
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px; color: white; text-align: center; margin: 30px 0;">
            <h2 style="margin: 0 0 15px 0;">Votre assistant IA immobilier est prêt !</h2>
            <p style="margin: 0; opacity: 0.9;">Générez du contenu professionnel en quelques clics</p>
          </div>
          
          <div style="margin: 30px 0;">
            <h3 style="color: #1f2937;">🚀 Commencez dès maintenant :</h3>
            <ul style="color: #4b5563; line-height: 1.6;">
              <li><strong>Annonces immobilières</strong> - Descriptions captivantes en 30 secondes</li>
              <li><strong>Posts réseaux sociaux</strong> - LinkedIn, Instagram, Facebook optimisés</li>
              <li><strong>Emails de prospection</strong> - Personnalisés selon votre cible</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 40px 0;">
            <a href="${loginUrl}" style="background: #3b82f6; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              🏠 Accéder à mon dashboard
            </a>
          </div>
          
          <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 40px; color: #6b7280; font-size: 14px;">
            <p><strong>Besoin d'aide ?</strong> Répondez à cet email ou contactez-nous sur <a href="mailto:support@immocontent.fr">support@immocontent.fr</a></p>
            <p style="margin-top: 20px;">ImmoContent - L'IA au service de l'immobilier</p>
          </div>
        </body>
      </html>
    `,
  },

  paymentSuccess: {
    subject: "✅ Paiement confirmé - Bienvenue dans ImmoContent Pro !",
    html: (name: string, plan: string, amount: number, features: string[]) => `
      <!DOCTYPE html>
      <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; border-radius: 12px; color: white; text-align: center;">
            <h1 style="margin: 0;">🎉 Paiement confirmé !</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Bienvenue dans ImmoContent ${plan}</p>
          </div>
          
          <div style="margin: 30px 0;">
            <h2 style="color: #1f2937;">Récapitulatif de votre abonnement :</h2>
            <div style="background: #f9fafb; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981;">
              <p><strong>Plan :</strong> ${plan}</p>
              <p><strong>Montant :</strong> ${amount}€/mois</p>
              <p><strong>Statut :</strong> ✅ Actif</p>
            </div>
          </div>
          
          <div style="margin: 30px 0;">
            <h3 style="color: #1f2937;">🚀 Vos nouvelles fonctionnalités :</h3>
            <ul style="color: #4b5563; line-height: 1.8;">
              ${features.map((feature) => `<li>✅ ${feature}</li>`).join("")}
            </ul>
          </div>
          
          <div style="text-align: center; margin: 40px 0;">
            <a href="${process.env.NEXT_PUBLIC_BASE_URL}/dashboard" style="background: #3b82f6; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              🏠 Découvrir mes nouvelles fonctionnalités
            </a>
          </div>
        </body>
      </html>
    `,
  },

  usageAlert: {
    subject: "⚠️ Limite d'utilisation atteinte - Passez au plan supérieur",
    html: (name: string, currentPlan: string, usage: number, limit: number) => `
      <!DOCTYPE html>
      <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px; border-radius: 12px; color: white; text-align: center;">
            <h1 style="margin: 0;">⚠️ Limite atteinte</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Vous avez utilisé ${usage}/${limit} générations ce mois</p>
          </div>
          
          <div style="margin: 30px 0;">
            <p>Bonjour ${name},</p>
            <p>Félicitations ! Vous utilisez intensivement ImmoContent. Vous avez atteint votre limite mensuelle de générations.</p>
            <p><strong>Pour continuer à générer du contenu sans interruption, passez au plan supérieur :</strong></p>
          </div>
          
          <div style="text-align: center; margin: 40px 0;">
            <a href="${process.env.NEXT_PUBLIC_BASE_URL}/tarifs" style="background: #3b82f6; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              🚀 Upgrader mon plan
            </a>
          </div>
        </body>
      </html>
    `,
  },
}

export class EmailService {
  static async sendWelcomeEmail(email: string, name: string) {
    try {
      const result = await resend.emails.send({
        from: "ImmoContent <onboarding@immocontent.fr>",
        to: email,
        subject: EMAIL_TEMPLATES.welcome.subject,
        html: EMAIL_TEMPLATES.welcome.html(name, `${process.env.NEXT_PUBLIC_BASE_URL}/dashboard`),
      })

      // Log email sent
      await supabase.from("email_logs").insert({
        email,
        type: "welcome",
        status: "sent",
        resend_id: result.data?.id,
      })

      return result
    } catch (error) {
      console.error("Failed to send welcome email:", error)
      await supabase.from("email_logs").insert({
        email,
        type: "welcome",
        status: "failed",
        error: error.message,
      })
      throw error
    }
  }

  static async sendPaymentConfirmation(email: string, name: string, plan: string, amount: number) {
    const features = {
      starter: ["100 générations/mois", "Support email", "Templates de base"],
      pro: ["Générations illimitées", "Support prioritaire", "Templates premium", "Intégrations CRM"],
      agence: ["Multi-utilisateurs", "Branding personnalisé", "API access", "Account manager dédié"],
    }

    try {
      const result = await resend.emails.send({
        from: "ImmoContent <billing@immocontent.fr>",
        to: email,
        subject: EMAIL_TEMPLATES.paymentSuccess.subject,
        html: EMAIL_TEMPLATES.paymentSuccess.html(name, plan, amount, features[plan] || []),
      })

      await supabase.from("email_logs").insert({
        email,
        type: "payment_success",
        status: "sent",
        resend_id: result.data?.id,
        metadata: { plan, amount },
      })

      return result
    } catch (error) {
      console.error("Failed to send payment confirmation:", error)
      throw error
    }
  }

  static async sendUsageAlert(email: string, name: string, currentPlan: string, usage: number, limit: number) {
    try {
      const result = await resend.emails.send({
        from: "ImmoContent <alerts@immocontent.fr>",
        to: email,
        subject: EMAIL_TEMPLATES.usageAlert.subject,
        html: EMAIL_TEMPLATES.usageAlert.html(name, currentPlan, usage, limit),
      })

      await supabase.from("email_logs").insert({
        email,
        type: "usage_alert",
        status: "sent",
        resend_id: result.data?.id,
        metadata: { currentPlan, usage, limit },
      })

      return result
    } catch (error) {
      console.error("Failed to send usage alert:", error)
      throw error
    }
  }
}
