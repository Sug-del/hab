// Cache Redis pour performance
import { Redis } from "@upstash/redis"

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})
\
export const cacheGet = async <T>(key: string)
: Promise<T | null> =>
{
  try {
    const cached = await redis.get(key)
    return cached ? JSON.parse(cached) as T : null
  } catch (error) {
    console.error("Cache get error:", error)
    return null
  }
}

export const cacheSet = async (key: string, value: any, ttl = 3600) => {
  try {
    await redis.setex(key, ttl, JSON.stringify(value))
  } catch (error) {
    console.error("Cache set error:", error)
  }
}

export const generateCacheKey = (type: string, params: any): string => {
  const hash = Buffer.from(JSON.stringify(params)).toString("base64")
  return `${type}:${hash}`
}
