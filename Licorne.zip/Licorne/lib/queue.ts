// Queue pour traitement asynchrone
import { Queue, Worker } from "bullmq"
import { Redis } from "ioredis"
import { processContentGeneration } from "./path-to-processContentGeneration" // Declare the variable before using it

const connection = new Redis(process.env.REDIS_URL!)

export const contentQueue = new Queue("content-generation", { connection })

export const addToQueue = async (type: string, data: any, userId: string) => {
  return await contentQueue.add(
    "generate-content",
    { type, data, userId },
    {
      attempts: 3,
      backoff: { type: "exponential", delay: 2000 },
      removeOnComplete: 100,
      removeOnFail: 50,
    },
  )
}

// Worker pour traiter la queue
export const startWorker = () => {
  const worker = new Worker(
    "content-generation",
    async (job) => {
      const { type, data, userId } = job.data
      // Traitement asynchrone de la génération
      return await processContentGeneration(type, data, userId)
    },
    { connection },
  )

  worker.on("completed", (job) => {
    console.log(`Job ${job.id} completed`)
  })

  worker.on("failed", (job, err) => {
    console.error(`Job ${job?.id} failed:`, err)
  })
}
