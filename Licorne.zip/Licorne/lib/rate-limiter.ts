import { Redis } from "@upstash/redis"
import { Ratelimit } from "@upstash/ratelimit"

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

// Rate limiters par type d'opération
export const rateLimiters = {
  // Génération de contenu - plus restrictif
  contentGeneration: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(10, "1 m"), // 10 générations par minute
    analytics: true,
  }),

  // API calls générales
  api: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(100, "1 m"), // 100 requêtes par minute
    analytics: true,
  }),

  // Authentification - très restrictif
  auth: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(5, "1 m"), // 5 tentatives par minute
    analytics: true,
  }),

  // Emails - modéré
  email: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(10, "1 h"), // 10 emails par heure
    analytics: true,
  }),
}

export async function checkRateLimit(
  type: keyof typeof rateLimiters,
  identifier: string,
): Promise<{ success: boolean; limit: number; remaining: number; reset: Date }> {
  const ratelimit = rateLimiters[type]
  const result = await ratelimit.limit(identifier)

  return {
    success: result.success,
    limit: result.limit,
    remaining: result.remaining,
    reset: new Date(result.reset),
  }
}

// Middleware pour rate limiting
export function withRateLimit(type: keyof typeof rateLimiters) {
  return async (req: Request, identifier?: string) => {
    const id = identifier || req.headers.get("x-forwarded-for") || "anonymous"
    const result = await checkRateLimit(type, id)

    if (!result.success) {
      return new Response(
        JSON.stringify({
          error: "Rate limit exceeded",
          limit: result.limit,
          remaining: result.remaining,
          reset: result.reset,
        }),
        {
          status: 429,
          headers: {
            "X-RateLimit-Limit": result.limit.toString(),
            "X-RateLimit-Remaining": result.remaining.toString(),
            "X-RateLimit-Reset": result.reset.getTime().toString(),
          },
        },
      )
    }

    return null // Continue
  }
}
