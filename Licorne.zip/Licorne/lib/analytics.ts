import { createClient } from "@supabase/supabase-js"
import { Logger } from "./monitoring"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export class Analytics {
  // Métriques business critiques
  static async trackContentGeneration(userId: string, type: "annonce" | "social" | "email", metadata: any) {
    try {
      await supabase.from("content_analytics").insert({
        user_id: userId,
        content_type: type,
        metadata: JSON.stringify(metadata),
        timestamp: new Date().toISOString(),
      })

      // Incrémenter compteur utilisateur
      await supabase.rpc("increment_user_usage", {
        user_id: userId,
        content_type: type,
      })
    } catch (error) {
      Logger.logError(new Error("Failed to track content generation"), { userId, type, error })
    }
  }

  static async trackUserEngagement(userId: string, action: string, metadata: any = {}) {
    try {
      await supabase.from("engagement_analytics").insert({
        user_id: userId,
        action,
        metadata: JSON.stringify(metadata),
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      Logger.logError(new Error("Failed to track engagement"), { userId, action, error })
    }
  }

  // Métriques de conversion
  static async trackConversion(
    userId: string,
    event: "signup" | "trial_start" | "subscription" | "churn",
    metadata: any = {},
  ) {
    try {
      await supabase.from("conversion_analytics").insert({
        user_id: userId,
        event,
        metadata: JSON.stringify(metadata),
        timestamp: new Date().toISOString(),
      })

      // Alertes pour événements critiques
      if (event === "churn") {
        // Déclencher alerte churn
        await this.sendChurnAlert(userId, metadata)
      }
    } catch (error) {
      Logger.logError(new Error("Failed to track conversion"), { userId, event, error })
    }
  }

  // Dashboard analytics en temps réel
  static async getDashboardMetrics(userId: string, period: "7d" | "30d" | "90d" = "30d") {
    const periodDays = period === "7d" ? 7 : period === "30d" ? 30 : 90

    try {
      // Générations par type
      const { data: contentStats } = await supabase
        .from("content_analytics")
        .select("content_type, created_at")
        .eq("user_id", userId)
        .gte("created_at", new Date(Date.now() - periodDays * 24 * 60 * 60 * 1000).toISOString())

      // Engagement metrics
      const { data: engagementStats } = await supabase
        .from("engagement_analytics")
        .select("action, created_at")
        .eq("user_id", userId)
        .gte("created_at", new Date(Date.now() - periodDays * 24 * 60 * 60 * 1000).toISOString())

      return {
        contentByType: this.groupByType(contentStats || []),
        dailyActivity: this.groupByDay(contentStats || []),
        engagementScore: this.calculateEngagementScore(engagementStats || []),
        totalGenerations: contentStats?.length || 0,
      }
    } catch (error) {
      Logger.logError(new Error("Failed to get dashboard metrics"), { userId, period, error })
      return null
    }
  }

  private static groupByType(data: any[]) {
    return data.reduce((acc, item) => {
      acc[item.content_type] = (acc[item.content_type] || 0) + 1
      return acc
    }, {})
  }

  private static groupByDay(data: any[]) {
    return data.reduce((acc, item) => {
      const day = new Date(item.created_at).toISOString().split("T")[0]
      acc[day] = (acc[day] || 0) + 1
      return acc
    }, {})
  }

  private static calculateEngagementScore(data: any[]) {
    // Algorithme simple d'engagement basé sur la fréquence d'utilisation
    const uniqueDays = new Set(data.map((item) => new Date(item.created_at).toISOString().split("T")[0])).size

    return Math.min(100, (uniqueDays / 30) * 100) // Score sur 100
  }

  private static async sendChurnAlert(userId: string, metadata: any) {
    // Webhook vers Slack/Discord pour alerter l'équipe
    try {
      await fetch(process.env.SLACK_WEBHOOK_URL!, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: `🚨 CHURN ALERT: User ${userId} has churned`,
          attachments: [
            {
              color: "danger",
              fields: [
                { title: "User ID", value: userId, short: true },
                { title: "Reason", value: metadata.reason || "Unknown", short: true },
                { title: "Last Activity", value: metadata.lastActivity || "Unknown", short: true },
              ],
            },
          ],
        }),
      })
    } catch (error) {
      Logger.logError(new Error("Failed to send churn alert"), { userId, error })
    }
  }
}
