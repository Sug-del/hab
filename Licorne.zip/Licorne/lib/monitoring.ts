import * as Sentry from "@sentry/nextjs"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Configuration Sentry avancée
export const initMonitoring = () => {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV,
    tracesSampleRate: process.env.NODE_ENV === "production" ? 0.1 : 1.0,
    profilesSampleRate: 0.1,
    beforeSend(event) {
      // Filtrer les erreurs non critiques
      if (event.exception) {
        const error = event.exception.values?.[0]
        if (error?.type === "ChunkLoadError" || error?.value?.includes("Loading chunk")) {
          return null // Ignorer les erreurs de chunk loading
        }
      }
      return event
    },
    integrations: [
      new Sentry.BrowserTracing({
        tracePropagationTargets: [process.env.NEXT_PUBLIC_BASE_URL!],
      }),
    ],
  })
}

// Système de logging avancé
export class Logger {
  static async logError(error: Error, context: any = {}, userId?: string) {
    // Sentry
    Sentry.withScope((scope) => {
      if (userId) scope.setUser({ id: userId })
      scope.setContext("error_context", context)
      Sentry.captureException(error)
    })

    // Database logging
    try {
      await supabase.from("error_logs").insert({
        error_message: error.message,
        error_stack: error.stack,
        context: JSON.stringify(context),
        user_id: userId,
        timestamp: new Date().toISOString(),
        severity: "error",
      })
    } catch (dbError) {
      console.error("Failed to log to database:", dbError)
    }

    // Console (development)
    if (process.env.NODE_ENV === "development") {
      console.error("🚨 Error logged:", error, context)
    }
  }

  static async logPerformance(operation: string, duration: number, metadata: any = {}) {
    // Sentry performance
    Sentry.addBreadcrumb({
      message: `${operation} completed in ${duration}ms`,
      level: "info",
      category: "performance",
      data: metadata,
    })

    // Database logging pour analytics
    try {
      await supabase.from("performance_logs").insert({
        operation,
        duration,
        metadata: JSON.stringify(metadata),
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Failed to log performance:", error)
    }
  }

  static async logUserAction(userId: string, action: string, metadata: any = {}) {
    try {
      await supabase.from("user_activity_logs").insert({
        user_id: userId,
        action,
        metadata: JSON.stringify(metadata),
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Failed to log user action:", error)
    }
  }
}

// Health check système
export class HealthCheck {
  static async checkSystemHealth() {
    const checks = {
      database: false,
      openai: false,
      stripe: false,
      email: false,
      timestamp: new Date().toISOString(),
    }

    // Check database
    try {
      await supabase.from("users").select("count").limit(1)
      checks.database = true
    } catch (error) {
      Logger.logError(new Error("Database health check failed"), { error })
    }

    // Check OpenAI
    try {
      const response = await fetch("https://api.openai.com/v1/models", {
        headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      })
      checks.openai = response.ok
    } catch (error) {
      Logger.logError(new Error("OpenAI health check failed"), { error })
    }

    // Log health status
    await supabase.from("health_checks").insert(checks)

    return checks
  }
}
