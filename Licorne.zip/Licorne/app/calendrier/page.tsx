"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, ChevronLeft, ChevronRight, Plus, Edit, Trash2, Clock } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

// Interface pour les événements du calendrier
interface CalendarEvent {
  id: string
  title: string
  type: "annonce" | "social" | "email"
  platform?: string
  date: string
  time: string
  status: "scheduled" | "published" | "draft"
}

export default function CalendrierPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [events] = useState<CalendarEvent[]>([
    {
      id: "1",
      title: "Post LinkedIn - Appartement T3",
      type: "social",
      platform: "linkedin",
      date: "2024-01-16",
      time: "14:00",
      status: "scheduled",
    },
    {
      id: "2",
      title: "Email prospection secteur Villeurbanne",
      type: "email",
      date: "2024-01-17",
      time: "09:00",
      status: "scheduled",
    },
    {
      id: "3",
      title: "Story Instagram - Visite virtuelle",
      type: "social",
      platform: "instagram",
      date: "2024-01-18",
      time: "16:00",
      status: "draft",
    },
    {
      id: "4",
      title: "Annonce - Maison familiale",
      type: "annonce",
      date: "2024-01-19",
      time: "10:00",
      status: "scheduled",
    },
  ])

  // Fonction pour obtenir les jours du mois
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []

    // Jours du mois précédent
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const prevDate = new Date(year, month, -i)
      days.push({ date: prevDate, isCurrentMonth: false })
    }

    // Jours du mois actuel
    for (let day = 1; day <= daysInMonth; day++) {
      days.push({ date: new Date(year, month, day), isCurrentMonth: true })
    }

    // Compléter avec les jours du mois suivant
    const remainingDays = 42 - days.length
    for (let day = 1; day <= remainingDays; day++) {
      days.push({ date: new Date(year, month + 1, day), isCurrentMonth: false })
    }

    return days
  }

  // Fonction pour obtenir les événements d'une date
  const getEventsForDate = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    return events.filter((event) => event.date === dateString)
  }

  // Navigation du calendrier
  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "annonce":
        return "bg-blue-100 text-blue-700"
      case "social":
        return "bg-purple-100 text-purple-700"
      case "email":
        return "bg-green-100 text-green-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-yellow-100 text-yellow-700"
      case "published":
        return "bg-green-100 text-green-700"
      case "draft":
        return "bg-gray-100 text-gray-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const days = getDaysInMonth(currentDate)
  const monthNames = [
    "Janvier",
    "Février",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Août",
    "Septembre",
    "Octobre",
    "Novembre",
    "Décembre",
  ]
  const dayNames = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Calendrier éditorial</h1>
          <div className="flex items-center gap-4">
            <Link href="/generateur/annonce">
              <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                <Plus className="w-4 h-4 mr-2" />
                Planifier du contenu
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Calendrier principal */}
          <div className="lg:col-span-3">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")}>
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("next")}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* En-têtes des jours */}
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {dayNames.map((day) => (
                    <div key={day} className="p-2 text-center text-sm font-medium text-slate-600">
                      {day}
                    </div>
                  ))}
                </div>

                {/* Grille du calendrier */}
                <div className="grid grid-cols-7 gap-1">
                  {days.map((day, index) => {
                    const dayEvents = getEventsForDate(day.date)
                    const isToday = day.date.toDateString() === new Date().toDateString()

                    return (
                      <div
                        key={index}
                        className={`min-h-[100px] p-2 border rounded-lg ${
                          day.isCurrentMonth ? "bg-white border-slate-200" : "bg-slate-50 border-slate-100"
                        } ${isToday ? "ring-2 ring-blue-500" : ""}`}
                      >
                        <div
                          className={`text-sm font-medium mb-2 ${
                            day.isCurrentMonth ? "text-slate-900" : "text-slate-400"
                          } ${isToday ? "text-blue-600" : ""}`}
                        >
                          {day.date.getDate()}
                        </div>

                        <div className="space-y-1">
                          {dayEvents.map((event) => (
                            <div
                              key={event.id}
                              className={`text-xs p-1 rounded ${getTypeColor(event.type)} cursor-pointer hover:opacity-80`}
                              title={`${event.title} - ${event.time}`}
                            >
                              <div className="font-medium truncate">{event.title}</div>
                              <div className="text-xs opacity-75">{event.time}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar avec événements à venir */}
          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Événements à venir</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {events
                    .filter((event) => new Date(event.date) >= new Date())
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .slice(0, 5)
                    .map((event) => (
                      <div key={event.id} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-slate-900 truncate">{event.title}</h4>
                          <p className="text-sm text-slate-600">
                            {new Date(event.date).toLocaleDateString("fr-FR")} à {event.time}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge className={getTypeColor(event.type)} variant="secondary">
                              {event.type}
                            </Badge>
                            <Badge className={getStatusColor(event.status)} variant="secondary">
                              {event.status === "scheduled"
                                ? "Programmé"
                                : event.status === "published"
                                  ? "Publié"
                                  : "Brouillon"}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Statistiques */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Statistiques du mois</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Contenus programmés</span>
                    <span className="font-semibold text-slate-900">
                      {events.filter((e) => e.status === "scheduled").length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Contenus publiés</span>
                    <span className="font-semibold text-slate-900">
                      {events.filter((e) => e.status === "published").length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Brouillons</span>
                    <span className="font-semibold text-slate-900">
                      {events.filter((e) => e.status === "draft").length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actions rapides */}
            <Card className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="w-6 h-6" />
                  <h3 className="font-semibold">Planification intelligente</h3>
                </div>
                <p className="text-indigo-100 text-sm leading-relaxed mb-4">
                  Laissez l'IA optimiser vos horaires de publication pour maximiser l'engagement.
                </p>
                <Button variant="secondary" size="sm" className="bg-white text-indigo-600 hover:bg-slate-50">
                  Optimiser automatiquement
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
