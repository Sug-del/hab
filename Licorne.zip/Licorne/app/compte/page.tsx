"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, CreditCard, Bell, Shield, Crown, Calendar, TrendingUp, Zap } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"
import { useAuth } from "@/components/auth-provider"

export default function ComptePage() {
  const { user } = useAuth()
  const [isLoading, setIsLoading] = useState(false)

  // Données mockées pour la démo
  const [userProfile, setUserProfile] = useState({
    name: user?.name || "Sophie Martineau",
    email: user?.email || "sophie@agence.fr",
    phone: "06 12 34 56 78",
    agency: "Century 21 Lyon",
    subscription: "pro",
    subscriptionDate: "2024-01-01",
    nextBilling: "2024-02-01",
    contentUsed: 47,
    contentLimit: 999999,
  })

  const [notifications, setNotifications] = useState({
    emailMarketing: true,
    contentReminders: true,
    weeklyReport: true,
    newFeatures: false,
  })

  const handleProfileUpdate = async () => {
    setIsLoading(true)
    // Simulation d'une mise à jour
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
    alert("Profil mis à jour avec succès !")
  }

  const handleCancelSubscription = async () => {
    if (confirm("Êtes-vous sûr de vouloir annuler votre abonnement ?")) {
      // Logique d'annulation Stripe
      alert("Abonnement annulé. Vous conservez l'accès jusqu'à la fin de la période.")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Mon compte</h1>
          <p className="text-slate-600">Gérez votre profil et vos paramètres</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Profil
            </TabsTrigger>
            <TabsTrigger value="subscription" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Abonnement
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Sécurité
            </TabsTrigger>
          </TabsList>

          {/* Onglet Profil */}
          <TabsContent value="profile">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle>Informations personnelles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nom complet</Label>
                    <Input
                      id="name"
                      value={userProfile.name}
                      onChange={(e) => setUserProfile((prev) => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={userProfile.email}
                      onChange={(e) => setUserProfile((prev) => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input
                      id="phone"
                      value={userProfile.phone}
                      onChange={(e) => setUserProfile((prev) => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="agency">Agence</Label>
                    <Input
                      id="agency"
                      value={userProfile.agency}
                      onChange={(e) => setUserProfile((prev) => ({ ...prev, agency: e.target.value }))}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleProfileUpdate}
                  disabled={isLoading}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  {isLoading ? "Mise à jour..." : "Mettre à jour le profil"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Abonnement */}
          <TabsContent value="subscription">
            <div className="space-y-6">
              {/* Plan actuel */}
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Plan actuel
                    <Badge className="bg-indigo-100 text-indigo-700 border-indigo-200">
                      <Crown className="w-4 h-4 mr-1" />
                      Plan Pro
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <p className="text-sm text-slate-600">Prix mensuel</p>
                      <p className="text-2xl font-bold text-slate-900">19€</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Prochaine facturation</p>
                      <p className="text-lg font-semibold text-slate-900">
                        {new Date(userProfile.nextBilling).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Contenus utilisés</p>
                      <p className="text-lg font-semibold text-slate-900">{userProfile.contentUsed} / Illimité</p>
                    </div>
                  </div>

                  <div className="mt-6 flex gap-4">
                    <Link href="/tarifs">
                      <Button variant="outline">Changer de plan</Button>
                    </Link>
                    <Button
                      variant="outline"
                      onClick={handleCancelSubscription}
                      className="text-red-600 border-red-200 hover:bg-red-50"
                    >
                      Annuler l'abonnement
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Historique de facturation */}
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Historique de facturation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { date: "2024-01-01", amount: "19€", status: "Payé" },
                      { date: "2023-12-01", amount: "19€", status: "Payé" },
                      { date: "2023-11-01", amount: "19€", status: "Payé" },
                    ].map((invoice, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-4">
                          <Calendar className="w-5 h-5 text-slate-400" />
                          <div>
                            <p className="font-medium text-slate-900">
                              {new Date(invoice.date).toLocaleDateString("fr-FR")}
                            </p>
                            <p className="text-sm text-slate-600">Plan Pro</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="font-semibold text-slate-900">{invoice.amount}</span>
                          <Badge className="bg-green-100 text-green-700">{invoice.status}</Badge>
                          <Button variant="ghost" size="sm">
                            Télécharger
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Statistiques d'utilisation */}
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Statistiques d'utilisation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <TrendingUp className="w-8 h-8 text-blue-600" />
                      </div>
                      <p className="text-2xl font-bold text-slate-900">47</p>
                      <p className="text-sm text-slate-600">Contenus générés ce mois</p>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Zap className="w-8 h-8 text-green-600" />
                      </div>
                      <p className="text-2xl font-bold text-slate-900">15h</p>
                      <p className="text-sm text-slate-600">Temps économisé</p>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Crown className="w-8 h-8 text-purple-600" />
                      </div>
                      <p className="text-2xl font-bold text-slate-900">92%</p>
                      <p className="text-sm text-slate-600">Taux de satisfaction</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Onglet Notifications */}
          <TabsContent value="notifications">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle>Préférences de notifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-slate-900">Emails marketing</h4>
                      <p className="text-sm text-slate-600">Recevez nos conseils et nouveautés</p>
                    </div>
                    <Button
                      variant={notifications.emailMarketing ? "default" : "outline"}
                      size="sm"
                      onClick={() =>
                        setNotifications((prev) => ({
                          ...prev,
                          emailMarketing: !prev.emailMarketing,
                        }))
                      }
                    >
                      {notifications.emailMarketing ? "Activé" : "Désactivé"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-slate-900">Rappels de contenu</h4>
                      <p className="text-sm text-slate-600">Notifications pour vos contenus programmés</p>
                    </div>
                    <Button
                      variant={notifications.contentReminders ? "default" : "outline"}
                      size="sm"
                      onClick={() =>
                        setNotifications((prev) => ({
                          ...prev,
                          contentReminders: !prev.contentReminders,
                        }))
                      }
                    >
                      {notifications.contentReminders ? "Activé" : "Désactivé"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-slate-900">Rapport hebdomadaire</h4>
                      <p className="text-sm text-slate-600">Résumé de vos performances chaque semaine</p>
                    </div>
                    <Button
                      variant={notifications.weeklyReport ? "default" : "outline"}
                      size="sm"
                      onClick={() =>
                        setNotifications((prev) => ({
                          ...prev,
                          weeklyReport: !prev.weeklyReport,
                        }))
                      }
                    >
                      {notifications.weeklyReport ? "Activé" : "Désactivé"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-slate-900">Nouvelles fonctionnalités</h4>
                      <p className="text-sm text-slate-600">Soyez informé des nouveautés en avant-première</p>
                    </div>
                    <Button
                      variant={notifications.newFeatures ? "default" : "outline"}
                      size="sm"
                      onClick={() =>
                        setNotifications((prev) => ({
                          ...prev,
                          newFeatures: !prev.newFeatures,
                        }))
                      }
                    >
                      {notifications.newFeatures ? "Activé" : "Désactivé"}
                    </Button>
                  </div>
                </div>

                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  Sauvegarder les préférences
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Sécurité */}
          <TabsContent value="security">
            <div className="space-y-6">
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Changer le mot de passe</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="currentPassword">Mot de passe actuel</Label>
                    <Input id="currentPassword" type="password" />
                  </div>
                  <div>
                    <Label htmlFor="newPassword">Nouveau mot de passe</Label>
                    <Input id="newPassword" type="password" />
                  </div>
                  <div>
                    <Label htmlFor="confirmPassword">Confirmer le nouveau mot de passe</Label>
                    <Input id="confirmPassword" type="password" />
                  </div>
                  <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    Mettre à jour le mot de passe
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Sessions actives</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div>
                        <p className="font-medium text-slate-900">Session actuelle</p>
                        <p className="text-sm text-slate-600">Chrome sur Windows • Lyon, France</p>
                        <p className="text-xs text-slate-500">Dernière activité : maintenant</p>
                      </div>
                      <Badge className="bg-green-100 text-green-700">Actuelle</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-red-50 border-red-200">
                <CardHeader>
                  <CardTitle className="text-red-800">Zone de danger</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-red-700 mb-4">
                    La suppression de votre compte est irréversible. Toutes vos données seront définitivement perdues.
                  </p>
                  <Button variant="outline" className="text-red-600 border-red-300 hover:bg-red-50">
                    Supprimer mon compte
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
