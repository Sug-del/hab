import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, ExternalLink, Copy } from "lucide-react"
import Link from "next/link"

const demoProfiles = [
  {
    id: "marie-designer",
    fullName: "Marie Dubois",
    nickname: "@mariedesign",
    bio: "Designer UI/UX passionnée par l'innovation et l'expérience utilisateur. J'aime créer des interfaces qui racontent une histoire.",
    emoji: "🎨",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: ["Dribbble", "Behance", "Instagram"],
    color: "from-pink-400 to-rose-400",
  },
  {
    id: "alex-dev",
    fullName: "Alex Martin",
    nickname: "@alexcode",
    bio: "Développeur full-stack et créateur de contenu. Je partage mes découvertes tech et mes projets open source.",
    emoji: "💻",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: ["GitHub", "Twitter", "YouTube"],
    color: "from-blue-400 to-cyan-400",
  },
  {
    id: "sophie-photo",
    fullName: "Sophie Leroy",
    nickname: "@sophiephoto",
    bio: "Photographe freelance spécialisée dans les portraits et les événements. Capturer l'émotion, c'est ma passion.",
    emoji: "📸",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: ["Instagram", "500px", "Site web"],
    color: "from-purple-400 to-indigo-400",
  },
  {
    id: "thomas-coach",
    fullName: "Thomas Rousseau",
    nickname: "@thomascoach",
    bio: "Coach en développement personnel et conférencier. J'accompagne les entrepreneurs dans leur croissance personnelle.",
    emoji: "🚀",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: ["LinkedIn", "YouTube", "Site web"],
    color: "from-green-400 to-emerald-400",
  },
]

export default function InspirationPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-orange-50">
      {/* Header */}
      <header className="px-6 py-4 border-b border-gray-200/50 bg-white/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Retour
          </Link>
          <Link href="/creer">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
              Créer ma page
            </Button>
          </Link>
        </div>
      </header>

      <main className="px-6 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Inspirez-vous de ces profils</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Découvrez comment d'autres utilisateurs ont créé leur page de présentation. Cliquez sur "Utiliser ce
              modèle" pour partir de leur base.
            </p>
          </div>

          {/* Demo Profiles Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {demoProfiles.map((profile) => (
              <Card
                key={profile.id}
                className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-shadow"
              >
                <CardContent className="p-8">
                  {/* Profile Header */}
                  <div className="text-center mb-6">
                    <div
                      className={`w-20 h-20 rounded-full mx-auto bg-gradient-to-r ${profile.color} flex items-center justify-center text-2xl text-white mb-4`}
                    >
                      {profile.emoji}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{profile.fullName}</h3>
                    <p className="text-gray-600">{profile.nickname}</p>
                  </div>

                  {/* Bio */}
                  <p className="text-gray-700 text-center mb-6 leading-relaxed">{profile.bio}</p>

                  {/* Social Links Preview */}
                  <div className="space-y-2 mb-6">
                    {profile.socialLinks.map((platform, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium text-gray-700">{platform}</span>
                        <ExternalLink className="w-4 h-4 text-gray-400" />
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <Link href={`/profil/${profile.id}`} className="flex-1">
                      <Button variant="outline" className="w-full">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Voir le profil
                      </Button>
                    </Link>
                    <Link href={`/creer?template=${profile.id}`} className="flex-1">
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                        <Copy className="w-4 h-4 mr-2" />
                        Utiliser ce modèle
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center mt-16">
            <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white max-w-2xl mx-auto">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold mb-4">Prêt à créer votre propre page ?</h2>
                <p className="text-purple-100 mb-6">
                  Rejoignez des milliers d'utilisateurs qui partagent déjà leur univers avec BioProfil.
                </p>
                <Link href="/creer">
                  <Button size="lg" variant="secondary" className="bg-white text-purple-600 hover:bg-gray-50">
                    Créer ma page gratuitement
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
