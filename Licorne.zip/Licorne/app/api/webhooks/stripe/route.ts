import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { createClient } from "@supabase/supabase-js"
import { sendPaymentConfirmation } from "@/lib/email"

const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = request.headers.get("stripe-signature")!

  let event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    console.error("Webhook signature verification failed:", err)
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object
        const userId = session.metadata?.user_id
        const planType = session.metadata?.plan_type

        if (userId && planType) {
          // Update user subscription
          await supabaseAdmin
            .from("users")
            .update({
              subscription_type: planType,
              content_limit: planType === "pro" ? 999999 : 50,
            })
            .eq("id", userId)

          // ✅ NOUVEAU : Envoyer email de confirmation
          const { data: user } = await supabaseAdmin.from("users").select("email, name").eq("id", userId).single()

          if (user) {
            await sendPaymentConfirmation(user.email, planType, session.amount_total! / 100)
          }
        }
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object
        const customerId = subscription.customer as string

        // Find user by Stripe customer ID
        const { data: user } = await supabaseAdmin
          .from("users")
          .select("id")
          .eq("stripe_customer_id", customerId)
          .single()

        if (user) {
          // Downgrade to free plan
          await supabaseAdmin
            .from("users")
            .update({
              subscription_type: "free",
              content_limit: 50,
            })
            .eq("id", user.id)
        }
        break
      }

      case "invoice.payment_failed": {
        // Handle failed payment
        console.log("Payment failed for subscription:", event.data.object.subscription)
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook handler error:", error)
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 })
  }
}
