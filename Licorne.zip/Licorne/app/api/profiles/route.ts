import { type NextRequest, NextResponse } from "next/server"

// Mock database - in a real app, this would be replaced with actual database calls
const profiles = new Map()

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Generate slug from full name
    const slug = data.fullName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")

    // Generate edit token
    const editToken = Math.random().toString(36).substring(2, 15)

    // Create profile object
    const profile = {
      id: Date.now().toString(),
      slug,
      fullName: data.fullName,
      nickname: data.nickname,
      bio: data.bio,
      emoji: data.emoji,
      profileImage: data.profileImage,
      socialLinks: data.socialLinks,
      editToken,
      createdAt: new Date().toISOString(),
    }

    // Store in mock database
    profiles.set(slug, profile)

    return NextResponse.json({
      success: true,
      slug,
      editToken,
      url: `/profil/${slug}`,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to create profile" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const slug = searchParams.get("slug")

  if (!slug) {
    return NextResponse.json({ success: false, error: "Slug is required" }, { status: 400 })
  }

  const profile = profiles.get(slug)

  if (!profile) {
    return NextResponse.json({ success: false, error: "Profile not found" }, { status: 404 })
  }

  return NextResponse.json({ success: true, profile })
}
