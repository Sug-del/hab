import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { contentType, propertyData, emailType, postPlatform, tone } = await request.json()

    if (!contentType || !propertyData) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    let systemPrompt = ""
    let userPrompt = ""

    if (contentType === "annonce") {
      systemPrompt = `Tu es un expert en rédaction d'annonces immobilières. Tu génères des annonces attractives et professionnelles qui donnent envie de visiter le bien.

Style : ${tone}
Format : Annonce immobilière complète avec titre accrocheur, description détaillée et informations pratiques.

Instructions :
- Utilise un titre percutant
- Mets en avant les points forts du bien
- Inclus les informations pratiques (prix, surface, localisation)
- Ajoute des emojis pour rendre l'annonce plus attractive
- Termine par les informations de contact
- Utilise des hashtags pertinents`

      userPrompt = `Génère une annonce immobilière pour :
Type : ${propertyData.type}
Pièces : ${propertyData.rooms}
Surface : ${propertyData.surface}m²
Prix : ${propertyData.price}€
Localisation : ${propertyData.location}
Description : ${propertyData.description || "Bien d'exception"}
Caractéristiques : ${propertyData.features?.join(", ") || "Aucune spécifiée"}`
    } else if (contentType === "email") {
      systemPrompt = `Tu es un agent immobilier professionnel qui rédige des emails personnalisés.

Style : ${tone}
Type d'email : ${emailType}

Instructions :
- Utilise un objet d'email accrocheur
- Personnalise le contenu selon le type d'email
- Reste professionnel mais chaleureux
- Inclus un appel à l'action clair
- Termine par une signature professionnelle`

      userPrompt = `Génère un email de ${emailType} pour le bien :
${propertyData.type} ${propertyData.rooms} - ${propertyData.location}
Prix : ${propertyData.price}€
Surface : ${propertyData.surface}m²`
    } else if (contentType === "post") {
      systemPrompt = `Tu es un expert en communication sur les réseaux sociaux pour l'immobilier.

Plateforme : ${postPlatform}
Style : ${tone}

Instructions :
- Adapte le contenu à la plateforme (LinkedIn plus professionnel, Instagram plus visuel)
- Utilise des emojis appropriés
- Inclus des hashtags pertinents
- Crée un contenu engageant qui incite à l'interaction
- Mets en avant les points forts du bien`

      userPrompt = `Génère un post ${postPlatform} pour :
${propertyData.type} ${propertyData.rooms}
${propertyData.location} - ${propertyData.price}€
Surface : ${propertyData.surface}m²
Description : ${propertyData.description || "Bien d'exception"}`
    }

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: userPrompt,
      maxTokens: 1000,
    })

    return NextResponse.json({
      success: true,
      content: text,
    })
  } catch (error) {
    console.error("Content generation error:", error)
    return NextResponse.json({ error: "Failed to generate content" }, { status: 500 })
  }
}
