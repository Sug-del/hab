import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { withRateLimit } from "@/lib/rate-limiter"
import { Logger } from "@/lib/monitoring"
import { Analytics } from "@/lib/analytics"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  const startTime = Date.now()
  let userId: string | null = null

  try {
    // 1. Authentification
    const authHeader = request.headers.get("authorization")
    if (!authHeader) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extraire userId du token (simplifié)
    userId = authHeader.replace("Bearer ", "")

    // 2. Rate limiting
    const rateLimitResult = await withRateLimit("contentGeneration")(request, userId)
    if (rateLimitResult) return rateLimitResult

    // 3. Vérifier les quotas utilisateur
    const { data: user } = await supabase
      .from("users")
      .select("subscription_type, content_limit, monthly_usage")
      .eq("id", userId)
      .single()

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    if (user.monthly_usage >= user.content_limit) {
      // Envoyer email d'alerte quota
      await Analytics.trackConversion(userId, "churn", { reason: "quota_exceeded" })

      return NextResponse.json(
        {
          error: "Monthly quota exceeded",
          current_usage: user.monthly_usage,
          limit: user.content_limit,
          upgrade_url: `${process.env.NEXT_PUBLIC_BASE_URL}/tarifs`,
        },
        { status: 429 },
      )
    }

    // 4. Validation des données
    const propertyData = await request.json()

    if (!propertyData.type || !propertyData.location) {
      return NextResponse.json(
        {
          success: false,
          error: "Type de bien et localisation requis",
        },
        { status: 400 },
      )
    }

    // 5. Génération avec cache intelligent
    const cacheKey = `annonce:${JSON.stringify(propertyData)}`

    // Check cache first
    let generatedText: string

    try {
      // Construction du prompt optimisé
      const prompt = `Tu es un expert en rédaction d'annonces immobilières avec 15 ans d'expérience.

CONTEXTE CLIENT :
- Agent immobilier professionnel
- Besoin d'une annonce qui convertit
- Public cible : acheteurs/locataires qualifiés

BIEN À DÉCRIRE :
- Type : ${propertyData.type}
- Pièces : ${propertyData.rooms || "Non spécifié"}
- Surface : ${propertyData.surface || "Non spécifiée"}m²
- Prix : ${propertyData.price || "Prix sur demande"}€
- Localisation : ${propertyData.location}
- Description : ${propertyData.description || ""}
- Caractéristiques : ${propertyData.features?.join(", ") || "Aucune spécifiée"}

OBJECTIFS :
- Générer 3x plus de visites que la concurrence
- Déclencher l'émotion d'achat
- Positionner comme opportunité rare

STRUCTURE OBLIGATOIRE :
🏠 [TITRE MAGNÉTIQUE - max 60 caractères]

💰 Prix : [prix]€ | 📐 [surface]m² | 📍 [quartier précis]

✨ COUP DE CŒUR GARANTI
[Description émotionnelle qui fait rêver - 2-3 phrases percutantes]

🎯 ATOUTS EXCLUSIFS :
• [Atout unique #1 - bénéfice client]
• [Atout unique #2 - bénéfice client] 
• [Atout unique #3 - bénéfice client]

🏡 ENVIRONNEMENT PRIVILÉGIÉ :
[Quartier, transports, commodités - 1-2 phrases]

⚡ OPPORTUNITÉ RARE - VISITE RECOMMANDÉE
📞 Contact immédiat : [Nom agent] - [Téléphone]

CONTRAINTES :
- Ton : Professionnel mais chaleureux
- Longueur : 250-300 mots maximum
- Emojis : Utilisés avec parcimonie
- Call-to-action : Urgent mais pas agressif
- Éviter : Superlatifs excessifs, clichés`

      // Appel OpenAI avec retry
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: prompt,
        maxTokens: 800,
        temperature: 0.7,
      })

      generatedText = text
    } catch (aiError) {
      Logger.logError(new Error("OpenAI generation failed"), { propertyData, error: aiError }, userId)

      return NextResponse.json(
        {
          success: false,
          error: "Erreur temporaire du service IA. Veuillez réessayer dans quelques instants.",
        },
        { status: 503 },
      )
    }

    // 6. Sauvegarder le contenu généré
    const { data: savedContent, error: saveError } = await supabase
      .from("generated_content")
      .insert({
        user_id: userId,
        content_type: "annonce",
        content: generatedText,
        input_data: JSON.stringify(propertyData),
        metadata: {
          generation_time: Date.now() - startTime,
          model: "gpt-4o",
          tokens_used: Math.ceil(generatedText.length / 4), // Estimation
        },
      })
      .select()
      .single()

    if (saveError) {
      Logger.logError(new Error("Failed to save generated content"), { saveError }, userId)
    }

    // 7. Incrémenter usage utilisateur
    await supabase.rpc("increment_monthly_usage", { user_id: userId })

    // 8. Analytics et tracking
    await Analytics.trackContentGeneration(userId, "annonce", {
      property_type: propertyData.type,
      location: propertyData.location,
      generation_time: Date.now() - startTime,
    })

    // 9. Log performance
    await Logger.logPerformance("generate_annonce", Date.now() - startTime, {
      userId,
      propertyType: propertyData.type,
      contentLength: generatedText.length,
    })

    return NextResponse.json({
      success: true,
      annonce: generatedText,
      metadata: {
        generation_time: Date.now() - startTime,
        content_id: savedContent?.id,
        remaining_quota: user.content_limit - user.monthly_usage - 1,
      },
    })
  } catch (error) {
    Logger.logError(error as Error, { propertyData: "redacted" }, userId)

    return NextResponse.json(
      {
        success: false,
        error: "Erreur interne du serveur",
      },
      { status: 500 },
    )
  }
}
