import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    const systemPrompt = `Tu es un expert développeur web qui génère du code HTML/CSS/JavaScript de haute qualité.
    
    Instructions:
    - Génère du code HTML complet avec Tailwind CSS
    - Le code doit être moderne, responsive et accessible
    - Utilise des couleurs harmonieuses et un design professionnel
    - Inclus des interactions JavaScript si nécessaire
    - Le code doit être prêt à être utilisé directement
    - Réponds uniquement avec le code HTML, sans explications
    - Utilise la langue française pour tous les textes
    
    Génère une page web complète basée sur cette demande:`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
      maxTokens: 4000,
    })

    // Extract project name from the generated content or prompt
    const projectName = prompt
      .split(" ")
      .slice(0, 4)
      .join(" ")
      .replace(/[^a-zA-Z0-9\s]/g, "")
      .trim()

    return NextResponse.json({
      success: true,
      code: text,
      projectName: projectName || "Nouveau projet",
    })
  } catch (error) {
    console.error("Generation error:", error)
    return NextResponse.json({ error: "Failed to generate code" }, { status: 500 })
  }
}
