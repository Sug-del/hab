import { type NextRequest, NextResponse } from "next/server"

// Mock database - in a real app, this would be replaced with actual database calls
const projects = new Map()

export async function POST(request: NextRequest) {
  try {
    const { name, prompt, code, userId } = await request.json()

    const project = {
      id: Date.now().toString(),
      name,
      prompt,
      code,
      userId: userId || "anonymous",
      createdAt: new Date().toISOString(),
      status: "completed",
    }

    projects.set(project.id, project)

    return NextResponse.json({
      success: true,
      project,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to save project" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const userId = searchParams.get("userId") || "anonymous"

  const userProjects = Array.from(projects.values()).filter((project) => project.userId === userId)

  return NextResponse.json({
    success: true,
    projects: userProjects,
  })
}
