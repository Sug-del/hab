import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const emailData = await request.json()

    // Vérification des données requises
    if (!emailData.type || !emailData.location) {
      return NextResponse.json(
        {
          success: false,
          error: "Type d'email et localisation requis",
        },
        { status: 400 },
      )
    }

    // Construction du prompt pour l'IA
    const prompt = `Tu es un expert en rédaction d'emails de prospection immobilière.

Génère un email de ${emailData.type} pour :
- Public cible : ${emailData.targetAudience}
- Zone géographique : ${emailData.location}
- Type de bien : ${emailData.propertyType || "Tous types"}
- Objectif : ${emailData.objective}
- Informations personnelles : ${emailData.personalInfo || "Agent immobilier professionnel"}
- Ton : ${emailData.tone}

L'email doit :
- Avoir un objet accrocheur et personnalisé
- Être personnalisé selon le public cible
- Inclure une proposition de valeur claire
- Avoir un appel à l'action précis
- Être professionnel mais humain
- Faire environ 150-250 mots
- Inclure une signature professionnelle

Format de sortie :
OBJET: [Objet de l'email]

CONTENU:
[Corps de l'email avec salutation, contenu principal, CTA et signature]`

    // Appel à l'API OpenAI
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: prompt,
      maxTokens: 600,
    })

    // Extraction de l'objet et du contenu
    const lines = text.split("\n")
    let subject = ""
    let content = ""
    let isContent = false

    for (const line of lines) {
      if (line.startsWith("OBJET:")) {
        subject = line.replace("OBJET:", "").trim()
      } else if (line.startsWith("CONTENU:")) {
        isContent = true
      } else if (isContent) {
        content += line + "\n"
      }
    }

    return NextResponse.json({
      success: true,
      email: {
        subject: subject || "Votre projet immobilier",
        content: content.trim() || text,
      },
    })
  } catch (error) {
    console.error("Erreur génération email:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erreur lors de la génération de l'email",
      },
      { status: 500 },
    )
  }
}
