import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const socialData = await request.json()

    // Vérification des données requises
    if (!socialData.propertyType || !socialData.location) {
      return NextResponse.json(
        {
          success: false,
          error: "Type de bien et localisation requis",
        },
        { status: 400 },
      )
    }

    const content = {
      linkedin: "",
      instagram: "",
      tiktok: "",
    }

    // Génération du contenu LinkedIn
    if (socialData.platform === "linkedin" || socialData.platform === "all") {
      const linkedinPrompt = `Génère un post LinkedIn professionnel pour un agent immobilier.

Informations :
- Bien : ${socialData.propertyType}
- Localisation : ${socialData.location}
- Prix : ${socialData.price || "Prix sur demande"}
- Accroche : ${socialData.hook || ""}
- CTA : ${socialData.callToAction || "Me contacter"}
- Ton : ${socialData.tone}

Le post doit :
- Être professionnel et engageant
- Inclure des emojis pertinents
- Avoir un hook accrocheur
- Inclure des hashtags immobilier
- Faire environ 150-200 mots
- Se terminer par un call-to-action clair

Format : Post LinkedIn complet avec emojis et hashtags`

      const { text: linkedinText } = await generateText({
        model: openai("gpt-4o"),
        prompt: linkedinPrompt,
        maxTokens: 400,
      })

      content.linkedin = linkedinText
    }

    // Génération du contenu Instagram
    if (socialData.platform === "instagram" || socialData.platform === "all") {
      const instagramPrompt = `Génère un post Instagram pour un agent immobilier.

Informations :
- Bien : ${socialData.propertyType}
- Localisation : ${socialData.location}
- Prix : ${socialData.price || "Prix sur demande"}
- Accroche : ${socialData.hook || ""}
- CTA : ${socialData.callToAction || "Me contacter"}
- Ton : ${socialData.tone}

Le post doit :
- Être visuel et accrocheur
- Utiliser beaucoup d'emojis
- Être court et impactant
- Inclure des hashtags tendance
- Faire environ 100-150 mots
- Être optimisé pour l'engagement

Format : Post Instagram avec emojis et hashtags`

      const { text: instagramText } = await generateText({
        model: openai("gpt-4o"),
        prompt: instagramPrompt,
        maxTokens: 300,
      })

      content.instagram = instagramText
    }

    // Génération du script TikTok
    if (socialData.platform === "tiktok" || socialData.platform === "all") {
      const tiktokPrompt = `Génère un script TikTok pour un agent immobilier.

Informations :
- Bien : ${socialData.propertyType}
- Localisation : ${socialData.location}
- Prix : ${socialData.price || "Prix sur demande"}
- Accroche : ${socialData.hook || ""}
- CTA : ${socialData.callToAction || "Me contacter"}
- Ton : ${socialData.tone}

Le script doit :
- Être dynamique et engageant
- Avoir un hook dans les 3 premières secondes
- Inclure des transitions visuelles
- Être structuré en séquences courtes
- Durer environ 30-60 secondes
- Inclure des moments "wow"

Format : Script TikTok avec indications visuelles et timing`

      const { text: tiktokText } = await generateText({
        model: openai("gpt-4o"),
        prompt: tiktokPrompt,
        maxTokens: 400,
      })

      content.tiktok = tiktokText
    }

    return NextResponse.json({
      success: true,
      content: content,
    })
  } catch (error) {
    console.error("Erreur génération contenu social:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erreur lors de la génération du contenu social",
      },
      { status: 500 },
    )
  }
}
