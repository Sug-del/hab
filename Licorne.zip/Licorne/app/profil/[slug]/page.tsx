import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Edit, Share2 } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import type { Metadata } from "next"

// Mock data - in a real app, this would come from a database
const mockProfiles = {
  "jean-dupont": {
    fullName: "Jean Dupont",
    nickname: "@jeandupont",
    bio: "Développeur passionné, amateur de café et de voyages. J'aime créer des expériences numériques qui ont du sens.",
    emoji: "💻",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: [
      { id: "1", platform: "Twitter", url: "https://twitter.com/jeandupont" },
      { id: "2", platform: "LinkedIn", url: "https://linkedin.com/in/jeandupont" },
      { id: "3", platform: "GitHub", url: "https://github.com/jeandupont" },
    ],
    editToken: "abc123",
  },
}

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params
  const profile = mockProfiles[slug as keyof typeof mockProfiles]

  if (!profile) {
    return {
      title: "Profil non trouvé - BioProfil",
    }
  }

  return {
    title: `${profile.fullName} - BioProfil`,
    description: profile.bio,
    openGraph: {
      title: profile.fullName,
      description: profile.bio,
      images: [profile.profileImage],
      type: "profile",
    },
    twitter: {
      card: "summary_large_image",
      title: profile.fullName,
      description: profile.bio,
      images: [profile.profileImage],
    },
  }
}

export default async function ProfilePage({ params }: PageProps) {
  const { slug } = await params
  const profile = mockProfiles[slug as keyof typeof mockProfiles]

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-orange-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Profil non trouvé</h1>
            <p className="text-gray-600 mb-6">Ce profil n'existe pas ou a été supprimé.</p>
            <Link href="/">
              <Button>Retour à l'accueil</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-orange-50">
      {/* Header */}
      <header className="px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="text-xl font-semibold text-gray-900">BioProfil</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Partager
            </Button>
            <Link href={`/modifier/${profile.editToken}`}>
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" />
                Modifier
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Profile */}
      <main className="px-6 py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardContent className="p-12 text-center">
              {/* Profile Image */}
              <div className="mb-8">
                <Image
                  src={profile.profileImage || "/placeholder.svg"}
                  alt={profile.fullName}
                  width={150}
                  height={150}
                  className="w-38 h-38 rounded-full mx-auto object-cover border-4 border-white shadow-lg"
                />
              </div>

              {/* Name and Nickname */}
              <div className="mb-6">
                <h1 className="text-4xl font-bold text-gray-900 mb-2">{profile.fullName}</h1>
                {profile.nickname && <p className="text-xl text-gray-600">{profile.nickname}</p>}
              </div>

              {/* Bio */}
              <p className="text-lg text-gray-700 mb-8 leading-relaxed max-w-lg mx-auto">{profile.bio}</p>

              {/* Social Links */}
              <div className="space-y-4 max-w-sm mx-auto">
                {profile.socialLinks.map((link) => (
                  <Button
                    key={link.id}
                    variant="outline"
                    size="lg"
                    className="w-full justify-between hover:bg-gray-50 hover:scale-105 transition-all"
                    asChild
                  >
                    <a href={link.url} target="_blank" rel="noopener noreferrer">
                      <span className="font-medium">{link.platform}</span>
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Create Your Own */}
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Vous aussi, créez votre page de présentation</p>
            <Link href="/creer">
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                Créer ma page gratuitement
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
