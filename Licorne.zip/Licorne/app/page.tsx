"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Building2, Sparkles, ArrowRight, Star, Users, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"

export default function HomePage() {
  const { user } = useAuth()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="border-b border-slate-200/60 bg-white/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                ImmoContent
              </span>
            </div>
            <div className="flex items-center gap-6">
              <Link
                href="/fonctionnalites"
                className="text-slate-600 hover:text-slate-900 font-medium transition-colors"
              >
                Fonctionnalités
              </Link>
              <Link href="/tarifs" className="text-slate-600 hover:text-slate-900 font-medium transition-colors">
                Tarifs
              </Link>
              {user ? (
                <Link href="/dashboard">
                  <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    Dashboard
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/auth/connexion">
                    <Button variant="outline" className="border-slate-300">
                      Connexion
                    </Button>
                  </Link>
                  <Link href="/auth/inscription">
                    <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      Essai gratuit
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <main className="px-6 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              IA spécialisée pour l'immobilier
            </div>

            <h1 className="text-6xl font-bold text-slate-900 mb-6 leading-tight">
              Automatisez votre
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                {" "}
                contenu immobilier
              </span>
              <br />
              en 30 secondes
            </h1>

            <p className="text-xl text-slate-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              Générez automatiquement vos annonces, posts sociaux et emails de prospection. Signez plus de mandats en
              gagnant 10h par semaine avec l'IA.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link href="/auth/inscription">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-4 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all"
                >
                  Commencer gratuitement
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/demo">
                <Button
                  variant="outline"
                  size="lg"
                  className="px-8 py-4 rounded-full text-lg font-medium border-2 hover:bg-slate-50 transition-all"
                >
                  Voir la démo
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid md:grid-cols-3 gap-8 mb-20">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">10h</div>
                <p className="text-slate-600">économisées par semaine</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">+250%</div>
                <p className="text-slate-600">de contenus générés</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">1500+</div>
                <p className="text-slate-600">agents utilisateurs</p>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-semibold text-slate-900">Annonces IA</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center leading-relaxed">
                  Créez des annonces immobilières percutantes en 30 secondes à partir des caractéristiques de votre
                  bien.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-semibold text-slate-900">Réseaux sociaux</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center leading-relaxed">
                  Posts LinkedIn, carrousels Instagram, scripts TikTok... Boostez votre présence digitale.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl font-semibold text-slate-900">Prospection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-center leading-relaxed">
                  Emails de prospection personnalisés pour décrocher plus de mandats et développer votre portefeuille.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Testimonials */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Ce que disent nos utilisateurs</h2>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: "Sophie Martineau",
                  role: "Agent immobilier - Century 21",
                  content:
                    "ImmoContent m'a révolutionné ! Mes annonces sont plus percutantes et j'ai signé 40% de mandats en plus ce trimestre.",
                  rating: 5,
                },
                {
                  name: "Marc Dubois",
                  role: "Directeur d'agence - Orpi",
                  content:
                    "Nos équipes sont 3x plus productives. L'outil s'adapte parfaitement à notre ton et nos processus métier.",
                  rating: 5,
                },
                {
                  name: "Julie Leroy",
                  role: "Mandataire indépendant",
                  content: "Interface intuitive, résultats bluffants. Je recommande à tous mes collègues !",
                  rating: 5,
                },
              ].map((testimonial, index) => (
                <Card key={index} className="bg-white border-slate-200/60">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-slate-700 mb-4 leading-relaxed">"{testimonial.content}"</p>
                    <div>
                      <p className="font-semibold text-slate-900">{testimonial.name}</p>
                      <p className="text-sm text-slate-500">{testimonial.role}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold mb-4">Prêt à automatiser votre contenu ?</h2>
              <p className="text-blue-100 mb-8 text-lg max-w-2xl mx-auto">
                Rejoignez plus de 1500 professionnels de l'immobilier qui utilisent ImmoContent.
              </p>
              <Link href="/auth/inscription">
                <Button
                  size="lg"
                  variant="secondary"
                  className="bg-white text-blue-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold"
                >
                  Essai gratuit 14 jours
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
