import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, Database, CreditCard, Zap, ExternalLink, Copy } from "lucide-react"
import Link from "next/link"

export default function ConfigurationPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Configuration requise</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Pour utiliser ImmoWriter, vous devez d'abord configurer les services externes. Suivez ce guide étape par
            étape.
          </p>
        </div>

        {/* Configuration Steps */}
        <div className="space-y-8">
          {/* Step 1: Supabase */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-bold">1</span>
                </div>
                <Database className="w-6 h-6 text-green-600" />
                Configurer Supabase (Base de données)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Étapes :</h4>
                <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700">
                  <li>
                    Créez un compte sur{" "}
                    <a
                      href="https://supabase.com"
                      target="_blank"
                      className="text-blue-600 hover:underline"
                      rel="noreferrer"
                    >
                      supabase.com
                    </a>
                  </li>
                  <li>Créez un nouveau projet</li>
                  <li>Allez dans Settings → API</li>
                  <li>Copiez l'URL du projet et la clé anon</li>
                  <li>Ajoutez-les dans votre fichier .env.local</li>
                </ol>
              </div>

              <div className="bg-slate-900 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-300 text-sm">Variables à ajouter :</span>
                  <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <pre className="text-green-400 text-sm">
                  {`NEXT_PUBLIC_SUPABASE_URL=https://votre-projet.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=votre-clé-anon
SUPABASE_SERVICE_ROLE_KEY=votre-service-role-key`}
                </pre>
              </div>

              <Link href="https://supabase.com" target="_blank">
                <Button className="bg-green-600 hover:bg-green-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Aller sur Supabase
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Step 2: OpenAI */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-bold">2</span>
                </div>
                <Zap className="w-6 h-6 text-purple-600" />
                Configurer OpenAI (IA)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Étapes :</h4>
                <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700">
                  <li>
                    Créez un compte sur{" "}
                    <a
                      href="https://platform.openai.com"
                      target="_blank"
                      className="text-blue-600 hover:underline"
                      rel="noreferrer"
                    >
                      platform.openai.com
                    </a>
                  </li>
                  <li>Allez dans API Keys</li>
                  <li>Créez une nouvelle clé API</li>
                  <li>Ajoutez du crédit à votre compte</li>
                </ol>
              </div>

              <div className="bg-slate-900 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-300 text-sm">Variable à ajouter :</span>
                  <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <pre className="text-green-400 text-sm">{`OPENAI_API_KEY=sk-...votre-clé-openai`}</pre>
              </div>

              <Link href="https://platform.openai.com" target="_blank">
                <Button className="bg-purple-600 hover:bg-purple-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Aller sur OpenAI
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Step 3: Stripe (Optional) */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold">3</span>
                </div>
                <CreditCard className="w-6 h-6 text-blue-600" />
                Configurer Stripe (Paiements) - Optionnel
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-blue-800 text-sm">
                  ⚠️ Cette étape est optionnelle. Vous pouvez utiliser ImmoWriter sans paiements pour tester.
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Étapes :</h4>
                <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700">
                  <li>
                    Créez un compte sur{" "}
                    <a
                      href="https://stripe.com"
                      target="_blank"
                      className="text-blue-600 hover:underline"
                      rel="noreferrer"
                    >
                      stripe.com
                    </a>
                  </li>
                  <li>Activez le mode test</li>
                  <li>Créez un produit "Plan Pro" à 19€/mois</li>
                  <li>Configurez les webhooks</li>
                </ol>
              </div>

              <Link href="https://stripe.com" target="_blank">
                <Button variant="outline" className="border-blue-200 text-blue-600 hover:bg-blue-50">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Aller sur Stripe
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Next Steps */}
        <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white border-0 mt-12">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Une fois configuré</h2>
            <p className="text-green-100 mb-6">
              Redémarrez votre serveur de développement et votre SaaS sera opérationnel !
            </p>
            <div className="bg-green-800 p-4 rounded-lg text-left">
              <code className="text-green-200">npm run dev</code>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
