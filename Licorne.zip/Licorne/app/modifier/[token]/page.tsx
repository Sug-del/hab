"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Save, Plus, X, Trash2 } from "lucide-react"
import Link from "next/link"
import { ProfilePreview } from "@/components/profile-preview"

interface SocialLink {
  id: string
  platform: string
  url: string
}

interface ProfileData {
  fullName: string
  nickname: string
  bio: string
  emoji: string
  profileImage: string
  socialLinks: SocialLink[]
}

interface PageProps {
  params: Promise<{ token: string }>
}

export default function EditPage({ params }: PageProps) {
  const [token, setToken] = useState<string>("")
  const [profileData, setProfileData] = useState<ProfileData>({
    fullName: "Jean Dupont",
    nickname: "@jeandupont",
    bio: "Développeur passionné, amateur de café et de voyages. J'aime créer des expériences numériques qui ont du sens.",
    emoji: "💻",
    profileImage: "/placeholder.svg?height=200&width=200",
    socialLinks: [
      { id: "1", platform: "Twitter", url: "https://twitter.com/jeandupont" },
      { id: "2", platform: "LinkedIn", url: "https://linkedin.com/in/jeandupont" },
      { id: "3", platform: "GitHub", url: "https://github.com/jeandupont" },
    ],
  })

  const [isLoading, setIsLoading] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  useEffect(() => {
    params.then(({ token }) => setToken(token))
  }, [params])

  const addSocialLink = () => {
    const newLink: SocialLink = {
      id: Date.now().toString(),
      platform: "",
      url: "",
    }
    setProfileData((prev) => ({
      ...prev,
      socialLinks: [...prev.socialLinks, newLink],
    }))
  }

  const updateSocialLink = (id: string, field: "platform" | "url", value: string) => {
    setProfileData((prev) => ({
      ...prev,
      socialLinks: prev.socialLinks.map((link) => (link.id === id ? { ...link, [field]: value } : link)),
    }))
  }

  const removeSocialLink = (id: string) => {
    setProfileData((prev) => ({
      ...prev,
      socialLinks: prev.socialLinks.filter((link) => link.id !== id),
    }))
  }

  const handleSave = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)

    // Show success message or redirect
    alert("Profil mis à jour avec succès !")
  }

  const handleDelete = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsLoading(false)

    // Redirect to home
    window.location.href = "/"
  }

  const commonEmojis = ["😊", "🚀", "💡", "🎨", "📱", "💻", "🌟", "🔥", "⚡", "🎯", "🌈", "🦄"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-orange-50">
      {/* Header */}
      <header className="px-6 py-4 border-b border-gray-200/50 bg-white/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link
            href="/profil/jean-dupont"
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Retour au profil
          </Link>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setShowDeleteConfirm(true)}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Supprimer
            </Button>
            <Button
              onClick={handleSave}
              disabled={!profileData.fullName || isLoading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {isLoading ? "Sauvegarde..." : "Sauvegarder"}
            </Button>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Form */}
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Modifier votre page</h1>
                <p className="text-gray-600">Mettez à jour vos informations et personnalisez votre page.</p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Informations personnelles</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="fullName">Nom complet *</Label>
                    <Input
                      id="fullName"
                      value={profileData.fullName}
                      onChange={(e) => setProfileData((prev) => ({ ...prev, fullName: e.target.value }))}
                      placeholder="Jean Dupont"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="nickname">Surnom ou pseudo</Label>
                    <Input
                      id="nickname"
                      value={profileData.nickname}
                      onChange={(e) => setProfileData((prev) => ({ ...prev, nickname: e.target.value }))}
                      placeholder="@jeandupont"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio courte</Label>
                    <Textarea
                      id="bio"
                      value={profileData.bio}
                      onChange={(e) => setProfileData((prev) => ({ ...prev, bio: e.target.value }))}
                      placeholder="Développeur passionné, amateur de café et de voyages..."
                      className="mt-1 resize-none"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Emoji favori</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {commonEmojis.map((emoji) => (
                        <button
                          key={emoji}
                          onClick={() => setProfileData((prev) => ({ ...prev, emoji }))}
                          className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center text-lg hover:bg-gray-50 transition-colors ${
                            profileData.emoji === emoji ? "border-purple-500 bg-purple-50" : "border-gray-200"
                          }`}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="profileImage">Photo de profil (URL)</Label>
                    <Input
                      id="profileImage"
                      value={profileData.profileImage}
                      onChange={(e) => setProfileData((prev) => ({ ...prev, profileImage: e.target.value }))}
                      placeholder="https://example.com/photo.jpg"
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Liens sociaux
                    <Button variant="outline" size="sm" onClick={addSocialLink} className="flex items-center gap-1">
                      <Plus className="w-4 h-4" />
                      Ajouter
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {profileData.socialLinks.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">Aucun lien ajouté pour le moment</p>
                  ) : (
                    profileData.socialLinks.map((link) => (
                      <div key={link.id} className="flex gap-2">
                        <Input
                          value={link.platform}
                          onChange={(e) => updateSocialLink(link.id, "platform", e.target.value)}
                          placeholder="Instagram"
                          className="flex-1"
                        />
                        <Input
                          value={link.url}
                          onChange={(e) => updateSocialLink(link.id, "url", e.target.value)}
                          placeholder="https://instagram.com/username"
                          className="flex-2"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeSocialLink(link.id)}
                          className="shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Preview */}
            <div className="sticky top-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Aperçu en temps réel</h2>
              <ProfilePreview data={profileData} />
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="max-w-md mx-4">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Supprimer votre page ?</h3>
              <p className="text-gray-600 mb-6">
                Cette action est irréversible. Votre page et toutes vos données seront définitivement supprimées.
              </p>
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setShowDeleteConfirm(false)} className="flex-1">
                  Annuler
                </Button>
                <Button
                  onClick={handleDelete}
                  disabled={isLoading}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                >
                  {isLoading ? "Suppression..." : "Supprimer"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
