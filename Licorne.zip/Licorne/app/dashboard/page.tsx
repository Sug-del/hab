"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, FileText, Users, Mail, Calendar, TrendingUp, Sparkles, Eye, Copy } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"
import { useAuth } from "@/components/auth-provider"

// Interface pour typer les données
interface ContentItem {
  id: string
  type: "annonce" | "social" | "email"
  title: string
  createdAt: string
  status: "draft" | "published"
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [recentContent, setRecentContent] = useState<ContentItem[]>([])
  const [stats, setStats] = useState({
    totalContent: 0,
    thisMonth: 0,
    emailsSent: 0,
    socialPosts: 0,
  })

  // Simulation de données (à remplacer par de vraies données Supabase)
  useEffect(() => {
    // Données mockées pour la démo
    setRecentContent([
      {
        id: "1",
        type: "annonce",
        title: "Appartement T3 Lyon 6ème",
        createdAt: "2024-01-15",
        status: "published",
      },
      {
        id: "2",
        type: "social",
        title: "Post LinkedIn - Maison familiale",
        createdAt: "2024-01-14",
        status: "draft",
      },
      {
        id: "3",
        type: "email",
        title: "Email prospection secteur Villeurbanne",
        createdAt: "2024-01-13",
        status: "published",
      },
    ])

    setStats({
      totalContent: 47,
      thisMonth: 12,
      emailsSent: 23,
      socialPosts: 15,
    })
  }, [])

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "annonce":
        return <Building2 className="w-4 h-4" />
      case "social":
        return <Users className="w-4 h-4" />
      case "email":
        return <Mail className="w-4 h-4" />
      default:
        return <FileText className="w-4 h-4" />
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "annonce":
        return "Annonce"
      case "social":
        return "Réseaux sociaux"
      case "email":
        return "Email"
      default:
        return "Contenu"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Bonjour {user?.name?.split(" ")[0] || "Agent"} ! 👋
          </h1>
          <p className="text-slate-600">Voici un aperçu de votre activité de contenu aujourd'hui.</p>
        </div>

        {/* Quick Actions */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0 mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold mb-2">Actions rapides</h2>
                <p className="text-blue-100">Que souhaitez-vous créer aujourd'hui ?</p>
              </div>

              <div className="flex items-center gap-3">
                <Link href="/generateur/annonce">
                  <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-0">
                    <Building2 className="w-4 h-4 mr-2" />
                    Annonce
                  </Button>
                </Link>

                <Link href="/generateur/social">
                  <Button variant="secondary" className="bg-white/20 hover:bg-white/30 text-white border-0">
                    <Users className="w-4 h-4 mr-2" />
                    Post social
                  </Button>
                </Link>

                <Link href="/generateur/email">
                  <Button variant="secondary" className="bg-white text-blue-600 hover:bg-slate-50">
                    <Mail className="w-4 h-4 mr-2" />
                    Email
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total contenus</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.totalContent}</p>
                  <p className="text-xs text-green-600">+{stats.thisMonth} ce mois</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Emails envoyés</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.emailsSent}</p>
                  <p className="text-xs text-green-600">+5 cette semaine</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Posts sociaux</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.socialPosts}</p>
                  <p className="text-xs text-blue-600">Ce mois-ci</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Taux d'engagement</p>
                  <p className="text-2xl font-bold text-slate-900">+24%</p>
                  <p className="text-xs text-green-600">vs mois dernier</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Content */}
          <div className="lg:col-span-2">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-xl font-semibold">Contenus récents</CardTitle>
                <Link href="/historique">
                  <Button variant="outline" size="sm">
                    Voir tout
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentContent.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          {getTypeIcon(item.type)}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">{item.title}</h3>
                          <p className="text-sm text-slate-600">
                            {getTypeLabel(item.type)} • {new Date(item.createdAt).toLocaleDateString("fr-FR")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge
                          variant={item.status === "published" ? "default" : "secondary"}
                          className={
                            item.status === "published"
                              ? "bg-green-100 text-green-700"
                              : "bg-yellow-100 text-yellow-700"
                          }
                        >
                          {item.status === "published" ? "Publié" : "Brouillon"}
                        </Badge>
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Calendar Widget */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold">Calendrier éditorial</CardTitle>
                <Link href="/calendrier">
                  <Button variant="outline" size="sm">
                    <Calendar className="w-4 h-4 mr-2" />
                    Voir tout
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Post LinkedIn</p>
                      <p className="text-xs text-slate-600">Aujourd'hui 14h00</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Email prospection</p>
                      <p className="text-xs text-slate-600">Demain 9h00</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Story Instagram</p>
                      <p className="text-xs text-slate-600">Jeudi 16h00</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Sparkles className="w-6 h-6" />
                  <h3 className="font-semibold">Conseil du jour</h3>
                </div>
                <p className="text-purple-100 text-sm leading-relaxed">
                  Publiez vos annonces entre 18h et 20h pour maximiser l'engagement. C'est le moment où vos prospects
                  consultent le plus les biens immobiliers !
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
