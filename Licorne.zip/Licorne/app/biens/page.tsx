"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  Search,
  Home,
  MapPin,
  Euro,
  Calendar,
  Eye,
  Edit,
  MoreHorizontal,
  FileText,
  MessageSquare,
  Share2,
} from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Property {
  id: string
  title: string
  type: string
  rooms: string
  surface: number
  price: number
  location: string
  status: "active" | "sold" | "pending" | "draft"
  createdAt: string
  contentGenerated: number
  views: number
  leads: number
  image?: string
}

export default function PropertiesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const [properties] = useState<Property[]>([
    {
      id: "1",
      title: "Appartement T3 lumineux avec balcon",
      type: "Appartement",
      rooms: "T3",
      surface: 85,
      price: 285000,
      location: "Lyon 6ème",
      status: "active",
      createdAt: "2024-01-15",
      contentGenerated: 5,
      views: 124,
      leads: 8,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "2",
      title: "Maison familiale avec jardin",
      type: "Maison",
      rooms: "T5",
      surface: 140,
      price: 450000,
      location: "Villeurbanne",
      status: "pending",
      createdAt: "2024-01-12",
      contentGenerated: 8,
      views: 89,
      leads: 12,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "3",
      title: "Studio moderne centre-ville",
      type: "Studio",
      rooms: "T1",
      surface: 32,
      price: 165000,
      location: "Lyon 2ème",
      status: "sold",
      createdAt: "2024-01-10",
      contentGenerated: 3,
      views: 67,
      leads: 5,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "4",
      title: "Loft industriel rénové",
      type: "Loft",
      rooms: "T4",
      surface: 120,
      price: 380000,
      location: "Lyon 1er",
      status: "active",
      createdAt: "2024-01-08",
      contentGenerated: 6,
      views: 156,
      leads: 15,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "5",
      title: "Villa avec piscine",
      type: "Villa",
      rooms: "T6",
      surface: 200,
      price: 750000,
      location: "Caluire-et-Cuire",
      status: "draft",
      createdAt: "2024-01-05",
      contentGenerated: 1,
      views: 23,
      leads: 2,
      image: "/placeholder.svg?height=200&width=300",
    },
  ])

  const filteredProperties = properties.filter((property) => {
    const matchesSearch =
      property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || property.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-700 border-green-200"
      case "sold":
        return "bg-blue-100 text-blue-700 border-blue-200"
      case "pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-200"
      case "draft":
        return "bg-slate-100 text-slate-700 border-slate-200"
      default:
        return "bg-slate-100 text-slate-700 border-slate-200"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Actif"
      case "sold":
        return "Vendu"
      case "pending":
        return "En cours"
      case "draft":
        return "Brouillon"
      default:
        return status
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Mes biens</h1>
            <p className="text-slate-600">{properties.length} biens au total</p>
          </div>
          <Link href="/biens/nouveau">
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau bien
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                <Input
                  placeholder="Rechercher un bien..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={statusFilter === "all" ? "default" : "outline"}
                  onClick={() => setStatusFilter("all")}
                  size="sm"
                >
                  Tous
                </Button>
                <Button
                  variant={statusFilter === "active" ? "default" : "outline"}
                  onClick={() => setStatusFilter("active")}
                  size="sm"
                >
                  Actifs
                </Button>
                <Button
                  variant={statusFilter === "pending" ? "default" : "outline"}
                  onClick={() => setStatusFilter("pending")}
                  size="sm"
                >
                  En cours
                </Button>
                <Button
                  variant={statusFilter === "sold" ? "default" : "outline"}
                  onClick={() => setStatusFilter("sold")}
                  size="sm"
                >
                  Vendus
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Properties Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProperties.map((property) => (
            <Card
              key={property.id}
              className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all group overflow-hidden"
            >
              {/* Property Image */}
              <div className="relative">
                <img
                  src={property.image || "/placeholder.svg"}
                  alt={property.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 left-4">
                  <Badge className={getStatusColor(property.status)}>{getStatusLabel(property.status)}</Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="secondary" size="sm" className="bg-white/90 backdrop-blur-sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="w-4 h-4 mr-2" />
                        Voir le détail
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="w-4 h-4 mr-2" />
                        Modifier
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <FileText className="w-4 h-4 mr-2" />
                        Générer contenu
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <CardContent className="p-6">
                {/* Property Info */}
                <div className="mb-4">
                  <h3 className="font-semibold text-slate-900 mb-2 line-clamp-2">{property.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                    <div className="flex items-center gap-1">
                      <Home className="w-4 h-4" />
                      <span>
                        {property.type} {property.rooms}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>{property.surface}m²</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-1 text-slate-600">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{property.location}</span>
                    </div>
                    <div className="flex items-center gap-1 font-semibold text-slate-900">
                      <Euro className="w-4 h-4" />
                      <span>{property.price.toLocaleString()}€</span>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-4 p-3 bg-slate-50 rounded-lg">
                  <div className="text-center">
                    <p className="text-sm font-semibold text-slate-900">{property.views}</p>
                    <p className="text-xs text-slate-600">Vues</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-semibold text-slate-900">{property.leads}</p>
                    <p className="text-xs text-slate-600">Leads</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-semibold text-slate-900">{property.contentGenerated}</p>
                    <p className="text-xs text-slate-600">Contenus</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Link href={`/contenu/nouveau?bien=${property.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      Contenu
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm">
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>

                {/* Created Date */}
                <div className="flex items-center gap-1 text-xs text-slate-500 mt-3">
                  <Calendar className="w-3 h-3" />
                  <span>Créé le {new Date(property.createdAt).toLocaleDateString("fr-FR")}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredProperties.length === 0 && (
          <Card className="bg-white/60 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <Home className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Aucun bien trouvé</h3>
              <p className="text-slate-600 mb-6">
                {searchTerm ? "Aucun bien ne correspond à votre recherche." : "Vous n'avez pas encore ajouté de bien."}
              </p>
              <Link href="/biens/nouveau">
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter mon premier bien
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
