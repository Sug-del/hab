import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Eye, Copy, Heart, Sparkles } from "lucide-react"
import Link from "next/link"

const publicProjects = [
  {
    id: "1",
    name: "Restaurant Moderne",
    description: "Page d'accueil élégante pour un restaurant gastronomique avec menu interactif et réservations",
    author: "Marie D.",
    likes: 124,
    category: "Restaurant",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["Restaurant", "Réservation", "Menu"],
  },
  {
    id: "2",
    name: "Dashboard SaaS",
    description: "Interface d'administration complète avec graphiques, métriques et gestion d'utilisateurs",
    author: "Thomas M.",
    likes: 89,
    category: "Dashboard",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["SaaS", "Analytics", "Admin"],
  },
  {
    id: "3",
    name: "Portfolio Créatif",
    description: "Site portfolio moderne pour designer avec galerie interactive et animations fluides",
    author: "Sophie L.",
    likes: 156,
    category: "Portfolio",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["Portfolio", "Design", "Créatif"],
  },
  {
    id: "4",
    name: "E-commerce Mode",
    description: "Boutique en ligne pour vêtements avec catalogue produits et panier d'achat",
    author: "Alex R.",
    likes: 203,
    category: "E-commerce",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["E-commerce", "Mode", "Boutique"],
  },
  {
    id: "5",
    name: "App Fitness",
    description: "Application de fitness avec suivi d'entraînements et programmes personnalisés",
    author: "Julie B.",
    likes: 78,
    category: "Fitness",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["Fitness", "Sport", "Santé"],
  },
  {
    id: "6",
    name: "Agence Immobilière",
    description: "Site d'agence immobilière avec recherche de biens et visites virtuelles",
    author: "Pierre K.",
    likes: 92,
    category: "Immobilier",
    preview: "/placeholder.svg?height=300&width=400",
    tags: ["Immobilier", "Recherche", "Visite"],
  },
]

const categories = ["Tous", "Restaurant", "Dashboard", "Portfolio", "E-commerce", "Fitness", "Immobilier"]

export default function GalleryPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b border-slate-200/60 bg-white/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                Retour
              </Link>
              <div className="h-6 w-px bg-slate-300" />
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-slate-900">Galerie</span>
              </div>
            </div>

            <Link href="/dashboard">
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                Créer le mien
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Galerie de projets</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Découvrez des applications créées par la communauté CodeGénie. Inspirez-vous et utilisez ces modèles pour
            vos propres projets.
          </p>
        </div>

        {/* Categories Filter */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={category === "Tous" ? "default" : "outline"}
              className={
                category === "Tous"
                  ? "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  : ""
              }
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {publicProjects.map((project) => (
            <Card
              key={project.id}
              className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-xl transition-all group overflow-hidden"
            >
              {/* Preview Image */}
              <div className="relative overflow-hidden">
                <img
                  src={project.preview || "/placeholder.svg"}
                  alt={project.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button size="sm" variant="secondary" className="bg-white/90 backdrop-blur-sm">
                    <Eye className="w-4 h-4 mr-2" />
                    Voir
                  </Button>
                </div>
              </div>

              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg font-semibold text-slate-900 mb-1 group-hover:text-indigo-600 transition-colors">
                      {project.name}
                    </CardTitle>
                    <p className="text-sm text-slate-600 line-clamp-2 leading-relaxed">{project.description}</p>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs bg-slate-100 text-slate-600">
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Author & Stats */}
                <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                  <span>Par {project.author}</span>
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4 text-red-400" />
                    <span>{project.likes}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Link href={`/projet/${project.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      <Eye className="w-4 h-4 mr-2" />
                      Voir le projet
                    </Button>
                  </Link>
                  <Link href={`/generateur?template=${project.id}`}>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Utiliser
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="px-8">
            Charger plus de projets
          </Button>
        </div>

        {/* CTA Section */}
        <div className="mt-20">
          <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold mb-4">Créez votre propre projet</h2>
              <p className="text-indigo-100 mb-8 text-lg max-w-2xl mx-auto">
                Rejoignez des milliers de créateurs qui utilisent CodeGénie pour donner vie à leurs idées en quelques
                secondes.
              </p>
              <Link href="/dashboard">
                <Button
                  size="lg"
                  variant="secondary"
                  className="bg-white text-indigo-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Commencer gratuitement
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
