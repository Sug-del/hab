"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Eye, Copy, Edit, Trash2, Download, Building2, Users, Mail, Calendar, TrendingUp } from "lucide-react"
import { DashboardHeader } from "@/components/dashboard-header"

// Interface pour l'historique des contenus
interface ContentHistory {
  id: string
  title: string
  type: "annonce" | "social" | "email"
  platform?: string
  createdAt: string
  status: "draft" | "published" | "scheduled"
  engagement?: {
    views: number
    clicks: number
    shares: number
  }
  content: string
}

export default function HistoriquePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")

  // Données mockées pour la démo
  const [contentHistory] = useState<ContentHistory[]>([
    {
      id: "1",
      title: "Appartement T3 lumineux - Lyon 6ème",
      type: "annonce",
      createdAt: "2024-01-15T10:30:00Z",
      status: "published",
      engagement: { views: 245, clicks: 23, shares: 5 },
      content: "🏠 COUP DE CŒUR - Appartement T3 de 85m² dans le prestigieux 6ème arrondissement...",
    },
    {
      id: "2",
      title: "Post LinkedIn - Conseils investissement",
      type: "social",
      platform: "linkedin",
      createdAt: "2024-01-14T14:20:00Z",
      status: "published",
      engagement: { views: 1250, clicks: 89, shares: 12 },
      content: "💡 5 conseils pour réussir votre premier investissement immobilier...",
    },
    {
      id: "3",
      title: "Email prospection secteur Villeurbanne",
      type: "email",
      createdAt: "2024-01-13T09:15:00Z",
      status: "published",
      engagement: { views: 156, clicks: 34, shares: 0 },
      content: "Objet: Votre projet immobilier à Villeurbanne\n\nBonjour...",
    },
    {
      id: "4",
      title: "Story Instagram - Visite virtuelle",
      type: "social",
      platform: "instagram",
      createdAt: "2024-01-12T16:45:00Z",
      status: "scheduled",
      content: "🏡 Découvrez cette magnifique maison en visite virtuelle...",
    },
    {
      id: "5",
      title: "Maison familiale avec jardin",
      type: "annonce",
      createdAt: "2024-01-11T11:00:00Z",
      status: "draft",
      content: "Charmante maison familiale de 140m² avec jardin arboré...",
    },
  ])

  // Filtrage des contenus
  const filteredContent = contentHistory.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.content.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || item.type === filterType
    const matchesStatus = filterStatus === "all" || item.status === filterStatus

    return matchesSearch && matchesType && matchesStatus
  })

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "annonce":
        return <Building2 className="w-4 h-4" />
      case "social":
        return <Users className="w-4 h-4" />
      case "email":
        return <Mail className="w-4 h-4" />
      default:
        return <Building2 className="w-4 h-4" />
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "annonce":
        return "Annonce"
      case "social":
        return "Réseaux sociaux"
      case "email":
        return "Email"
      default:
        return "Contenu"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "published":
        return "bg-green-100 text-green-700"
      case "scheduled":
        return "bg-yellow-100 text-yellow-700"
      case "draft":
        return "bg-gray-100 text-gray-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "published":
        return "Publié"
      case "scheduled":
        return "Programmé"
      case "draft":
        return "Brouillon"
      default:
        return status
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Historique des contenus</h1>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </Button>
        </div>

        {/* Statistiques rapides */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total contenus</p>
                  <p className="text-2xl font-bold text-slate-900">{contentHistory.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Publiés</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {contentHistory.filter((c) => c.status === "published").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Vues totales</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {contentHistory.reduce((sum, c) => sum + (c.engagement?.views || 0), 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Eye className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Taux d'engagement</p>
                  <p className="text-2xl font-bold text-slate-900">4.2%</p>
                  <p className="text-xs text-green-600">+0.8% ce mois</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtres et recherche */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                <Input
                  placeholder="Rechercher dans vos contenus..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filterType === "all" ? "default" : "outline"}
                  onClick={() => setFilterType("all")}
                  size="sm"
                >
                  Tous
                </Button>
                <Button
                  variant={filterType === "annonce" ? "default" : "outline"}
                  onClick={() => setFilterType("annonce")}
                  size="sm"
                >
                  Annonces
                </Button>
                <Button
                  variant={filterType === "social" ? "default" : "outline"}
                  onClick={() => setFilterType("social")}
                  size="sm"
                >
                  Social
                </Button>
                <Button
                  variant={filterType === "email" ? "default" : "outline"}
                  onClick={() => setFilterType("email")}
                  size="sm"
                >
                  Emails
                </Button>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filterStatus === "all" ? "default" : "outline"}
                  onClick={() => setFilterStatus("all")}
                  size="sm"
                >
                  Tous statuts
                </Button>
                <Button
                  variant={filterStatus === "published" ? "default" : "outline"}
                  onClick={() => setFilterStatus("published")}
                  size="sm"
                >
                  Publiés
                </Button>
                <Button
                  variant={filterStatus === "draft" ? "default" : "outline"}
                  onClick={() => setFilterStatus("draft")}
                  size="sm"
                >
                  Brouillons
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Liste des contenus */}
        <div className="space-y-4">
          {filteredContent.map((item) => (
            <Card
              key={item.id}
              className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      {getTypeIcon(item.type)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-slate-900 truncate">{item.title}</h3>
                        <Badge className={getStatusColor(item.status)} variant="secondary">
                          {getStatusLabel(item.status)}
                        </Badge>
                        {item.platform && (
                          <Badge variant="outline" className="text-xs">
                            {item.platform}
                          </Badge>
                        )}
                      </div>

                      <p className="text-sm text-slate-600 mb-3 line-clamp-2">{item.content}</p>

                      <div className="flex items-center gap-6 text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(item.createdAt).toLocaleDateString("fr-FR")}
                        </div>
                        <div className="flex items-center gap-1">
                          <span>{getTypeLabel(item.type)}</span>
                        </div>
                        {item.engagement && (
                          <>
                            <div className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              {item.engagement.views} vues
                            </div>
                            <div className="flex items-center gap-1">
                              <TrendingUp className="w-4 h-4" />
                              {item.engagement.clicks} clics
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Message si aucun résultat */}
        {filteredContent.length === 0 && (
          <Card className="bg-white/60 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <Search className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Aucun contenu trouvé</h3>
              <p className="text-slate-600 mb-6">Aucun contenu ne correspond à vos critères de recherche.</p>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setFilterType("all")
                  setFilterStatus("all")
                }}
              >
                Réinitialiser les filtres
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
