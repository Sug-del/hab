"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Check, Sparkles, Zap, Crown, Loader2 } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase"
import { loadStripe } from "@stripe/stripe-js"

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function PricingPage() {
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [currentPlan, setCurrentPlan] = useState<string>("starter")

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        setUser(user)
        // Get user subscription info
        const { data: userData } = await supabase.from("users").select("subscription_type").eq("id", user.id).single()

        if (userData) {
          setCurrentPlan(userData.subscription_type)
        }
      }
    }
    getUser()
  }, [])

  const handleUpgrade = async (planType: string) => {
    if (!user) {
      // Redirect to login
      window.location.href = "/auth/connexion"
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ planType }),
      })

      const { sessionId } = await response.json()
      const stripe = await stripePromise

      if (stripe) {
        await stripe.redirectToCheckout({ sessionId })
      }
    } catch (error) {
      console.error("Error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b border-slate-200/60 bg-white/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <nav className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Retour
            </Link>
            {user ? (
              <Link href="/dashboard">
                <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                  Dashboard
                </Button>
              </Link>
            ) : (
              <div className="flex items-center gap-4">
                <Link href="/auth/connexion">
                  <Button variant="outline">Connexion</Button>
                </Link>
                <Link href="/auth/inscription">
                  <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                    Commencer
                  </Button>
                </Link>
              </div>
            )}
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-16">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">Choisissez votre plan</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Commencez avec le plan Starter et passez à Pro quand vous êtes prêt à créer sans limites.
          </p>
          {currentPlan === "pro" && (
            <div className="mt-4 inline-flex items-center gap-2 bg-green-50 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
              <Crown className="w-4 h-4" />
              Vous êtes actuellement sur le plan Pro
            </div>
          )}
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Starter Plan */}
          <Card
            className={`bg-white/80 backdrop-blur-sm border-slate-200/60 relative ${currentPlan === "starter" ? "ring-2 ring-green-500" : ""}`}
          >
            {currentPlan === "starter" && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-medium">Plan actuel</div>
              </div>
            )}

            <CardHeader className="text-center pb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-900">Starter</CardTitle>
              <div className="text-4xl font-bold text-slate-900 mt-4">
                9€
                <span className="text-lg font-normal text-slate-500">/mois</span>
              </div>
              <p className="text-slate-600 mt-2">Parfait pour commencer</p>
            </CardHeader>

            <CardContent className="space-y-6">
              <ul className="space-y-4">
                {[
                  "50 contenus par mois",
                  "Générateurs IA (annonces, social, emails)",
                  "Calendrier éditorial",
                  "Historique des contenus",
                  "Support par email",
                ].map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500 shrink-0" />
                    <span className="text-slate-700">{feature}</span>
                  </li>
                ))}
              </ul>

              {currentPlan === "starter" ? (
                <Button disabled className="w-full bg-green-500 text-white">
                  Plan actuel
                </Button>
              ) : (
                <Button
                  onClick={() => handleUpgrade("starter")}
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Redirection...
                    </>
                  ) : (
                    "Choisir Starter"
                  )}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Pro Plan */}
          <Card
            className={`bg-white/80 backdrop-blur-sm border-indigo-200/60 relative overflow-hidden ${currentPlan === "pro" ? "ring-2 ring-indigo-500" : ""}`}
          >
            {currentPlan === "pro" ? (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-indigo-500 text-white px-4 py-1 rounded-full text-sm font-medium">Plan actuel</div>
              </div>
            ) : (
              <div className="absolute top-0 right-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-1 text-sm font-semibold">
                Populaire
              </div>
            )}

            <CardHeader className="text-center pb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-900">Pro</CardTitle>
              <div className="text-4xl font-bold text-slate-900 mt-4">
                29€
                <span className="text-lg font-normal text-slate-500">/mois</span>
              </div>
              <p className="text-slate-600 mt-2">Pour les agents professionnels</p>
            </CardHeader>

            <CardContent className="space-y-6">
              <ul className="space-y-4">
                {[
                  "Contenus illimités",
                  "Tous les générateurs IA",
                  "Calendrier éditorial avancé",
                  "Planification automatique",
                  "Statistiques détaillées",
                  "Export et intégrations",
                  "Support prioritaire",
                  "Accès aux nouvelles fonctionnalités",
                ].map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-indigo-500 shrink-0" />
                    <span className="text-slate-700">{feature}</span>
                  </li>
                ))}
              </ul>

              {currentPlan === "pro" ? (
                <Button disabled className="w-full bg-indigo-500 text-white">
                  Plan actuel
                </Button>
              ) : (
                <Button
                  onClick={() => handleUpgrade("pro")}
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Redirection...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      Passer à Pro
                    </>
                  )}
                </Button>
              )}

              <p className="text-center text-sm text-slate-500">Annulation possible à tout moment</p>
            </CardContent>
          </Card>

          {/* Agence Plan */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 relative">
            <CardHeader className="text-center pb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-900">Agence</CardTitle>
              <div className="text-4xl font-bold text-slate-900 mt-4">
                99€
                <span className="text-lg font-normal text-slate-500">/mois</span>
              </div>
              <p className="text-slate-600 mt-2">Pour les équipes et agences</p>
            </CardHeader>

            <CardContent className="space-y-6">
              <ul className="space-y-4">
                {[
                  "Tout du plan Pro",
                  "5 utilisateurs inclus",
                  "Gestion d'équipe",
                  "Workflows collaboratifs",
                  "Branding personnalisé",
                  "API access",
                  "Formation dédiée",
                  "Support téléphonique",
                ].map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-purple-500 shrink-0" />
                    <span className="text-slate-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                onClick={() => handleUpgrade("agence")}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Redirection...
                  </>
                ) : (
                  "Choisir Agence"
                )}
              </Button>

              <p className="text-center text-sm text-slate-500">Facturation annuelle disponible</p>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Questions fréquentes</h2>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                question: "Puis-je changer de plan à tout moment ?",
                answer:
                  "Oui, vous pouvez passer à un plan supérieur ou annuler votre abonnement à tout moment depuis votre dashboard.",
              },
              {
                question: "Que se passe-t-il si je dépasse ma limite ?",
                answer:
                  "Sur le plan Starter, vous ne pourrez plus générer de contenu jusqu'au mois suivant. Le plan Pro n'a pas de limite.",
              },
              {
                question: "Y a-t-il un engagement ?",
                answer:
                  "Aucun engagement. Vous pouvez annuler votre abonnement à tout moment et continuer à utiliser vos contenus existants.",
              },
              {
                question: "Les données sont-elles sécurisées ?",
                answer:
                  "Oui, toutes vos données sont chiffrées et stockées de manière sécurisée. Nous respectons le RGPD.",
              },
            ].map((faq, index) => (
              <Card key={index} className="bg-white/60 backdrop-blur-sm border-slate-200/60">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-slate-900 mb-2">{faq.question}</h3>
                  <p className="text-slate-600 leading-relaxed">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20">
          <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-0">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold mb-4">Prêt à automatiser votre contenu immobilier ?</h2>
              <p className="text-indigo-100 mb-8 text-lg max-w-2xl mx-auto">
                Rejoignez plus de 1500 agents immobiliers qui utilisent ImmoContent pour booster leur productivité.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                {!user ? (
                  <Link href="/auth/inscription">
                    <Button
                      size="lg"
                      variant="secondary"
                      className="bg-white text-indigo-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold"
                    >
                      Essai gratuit 14 jours
                    </Button>
                  </Link>
                ) : currentPlan === "starter" ? (
                  <Button
                    size="lg"
                    variant="secondary"
                    onClick={() => handleUpgrade("pro")}
                    disabled={isLoading}
                    className="bg-white text-indigo-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Redirection...
                      </>
                    ) : (
                      "Passer à Pro"
                    )}
                  </Button>
                ) : (
                  <Link href="/dashboard">
                    <Button
                      size="lg"
                      variant="secondary"
                      className="bg-white text-indigo-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold"
                    >
                      Accéder au dashboard
                    </Button>
                  </Link>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
