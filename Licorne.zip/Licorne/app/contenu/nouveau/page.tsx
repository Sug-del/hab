"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Sparkles, FileText, MessageSquare, Share2, Copy, Check, Wand2, Settings } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

interface PropertyData {
  type: string
  surface: string
  rooms: string
  price: string
  location: string
  description: string
  features: string[]
}

export default function NewContentPage() {
  const [contentType, setContentType] = useState<"annonce" | "email" | "post">("annonce")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedContent, setGeneratedContent] = useState("")
  const [copied, setCopied] = useState(false)

  const [propertyData, setPropertyData] = useState<PropertyData>({
    type: "",
    surface: "",
    rooms: "",
    price: "",
    location: "",
    description: "",
    features: [],
  })

  const [emailType, setEmailType] = useState("")
  const [postPlatform, setPostPlatform] = useState("")
  const [tone, setTone] = useState("professionnel")

  const handleGenerate = async () => {
    setIsGenerating(true)

    // Simulate AI generation
    await new Promise((resolve) => setTimeout(resolve, 3000))

    let content = ""

    if (contentType === "annonce") {
      content = `🏠 ${propertyData.type} ${propertyData.rooms} - ${propertyData.location}

💰 Prix : ${propertyData.price}€
📐 Surface : ${propertyData.surface}m²

✨ Description :
${propertyData.description || "Magnifique propriété située dans un quartier recherché. Ce bien d'exception vous séduira par ses volumes généreux et sa luminosité exceptionnelle."}

🎯 Points forts :
${propertyData.features.length > 0 ? propertyData.features.map((f) => `• ${f}`).join("\n") : "• Emplacement privilégié\n• Prestations de qualité\n• Proche commodités"}

📞 Contact : Sophie Martineau - Agent immobilier
📧 sophie.martineau@agence.fr
📱 06 12 34 56 78

#Immobilier #${propertyData.location.replace(/\s+/g, "")} #AVendre`
    } else if (contentType === "email") {
      if (emailType === "prospection") {
        content = `Objet : Votre projet immobilier à ${propertyData.location}

Bonjour,

J'espère que vous allez bien. Je me permets de vous contacter car j'ai remarqué votre intérêt pour l'immobilier dans le secteur de ${propertyData.location}.

Je dispose actuellement d'un ${propertyData.type.toLowerCase()} de ${propertyData.surface}m² qui pourrait parfaitement correspondre à vos critères :

🏠 ${propertyData.type} ${propertyData.rooms}
📍 ${propertyData.location}
💰 ${propertyData.price}€
📐 ${propertyData.surface}m²

Ce bien présente de nombreux atouts et se situe dans un secteur très recherché. Je serais ravie de vous en dire plus et d'organiser une visite si cela vous intéresse.

Seriez-vous disponible cette semaine pour un échange téléphonique ?

Bien cordialement,

Sophie Martineau
Agent immobilier certifié
📱 06 12 34 56 78
📧 sophie.martineau@agence.fr`
      } else {
        content = `Objet : Confirmation de votre visite - ${propertyData.type} ${propertyData.location}

Bonjour,

Je vous confirme notre rendez-vous pour la visite du ${propertyData.type.toLowerCase()} situé à ${propertyData.location}.

📅 Date : [À compléter]
🕐 Heure : [À compléter]
📍 Adresse : ${propertyData.location}

Caractéristiques du bien :
• Surface : ${propertyData.surface}m²
• Prix : ${propertyData.price}€
• ${propertyData.rooms}

N'hésitez pas à préparer vos questions, je serai là pour vous accompagner et vous donner toutes les informations nécessaires.

En cas d'empêchement, merci de me prévenir au plus tôt.

À très bientôt,

Sophie Martineau
📱 06 12 34 56 78`
      }
    } else if (contentType === "post") {
      if (postPlatform === "linkedin") {
        content = `🏠 Nouvelle opportunité immobilière à ${propertyData.location} !

Je suis ravie de vous présenter ce magnifique ${propertyData.type.toLowerCase()} de ${propertyData.surface}m² qui vient d'arriver sur le marché.

🎯 Les points forts :
• ${propertyData.rooms}
• Surface optimisée de ${propertyData.surface}m²
• Emplacement privilégié à ${propertyData.location}
• Prix attractif : ${propertyData.price}€

${propertyData.description || "Un bien d'exception qui saura séduire les acquéreurs les plus exigeants."}

Vous cherchez un bien similaire ou souhaitez plus d'informations ? 
👉 Contactez-moi en MP ou au 06 12 34 56 78

#Immobilier #${propertyData.location.replace(/\s+/g, "")} #InvestissementImmobilier #AgentImmobilier`
      } else {
        content = `✨ Coup de cœur immobilier ✨

📍 ${propertyData.location}
🏠 ${propertyData.type} ${propertyData.rooms}
📐 ${propertyData.surface}m²
💰 ${propertyData.price}€

${propertyData.description || "Un bien rare qui ne restera pas longtemps sur le marché ! 😍"}

DM pour plus d'infos 📩

#immobilier #${propertyData.location.toLowerCase().replace(/\s+/g, "")} #maison #appartement #avendre #agentimmobilier #bienimmobilier`
      }
    }

    setGeneratedContent(content)
    setIsGenerating(false)
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(generatedContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const addFeature = (feature: string) => {
    if (feature && !propertyData.features.includes(feature)) {
      setPropertyData((prev) => ({
        ...prev,
        features: [...prev.features, feature],
      }))
    }
  }

  const removeFeature = (feature: string) => {
    setPropertyData((prev) => ({
      ...prev,
      features: prev.features.filter((f) => f !== feature),
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Générer du contenu</h1>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Configuration */}
          <div className="space-y-6">
            {/* Content Type Selection */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-blue-600" />
                  Type de contenu
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3">
                  <Button
                    variant={contentType === "annonce" ? "default" : "outline"}
                    onClick={() => setContentType("annonce")}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <FileText className="w-6 h-6" />
                    <span>Annonce</span>
                  </Button>
                  <Button
                    variant={contentType === "email" ? "default" : "outline"}
                    onClick={() => setContentType("email")}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <MessageSquare className="w-6 h-6" />
                    <span>Email</span>
                  </Button>
                  <Button
                    variant={contentType === "post" ? "default" : "outline"}
                    onClick={() => setContentType("post")}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Share2 className="w-6 h-6" />
                    <span>Post social</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Property Information */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle>Informations du bien</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="type">Type de bien</Label>
                    <Select
                      value={propertyData.type}
                      onValueChange={(value) => setPropertyData((prev) => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Appartement">Appartement</SelectItem>
                        <SelectItem value="Maison">Maison</SelectItem>
                        <SelectItem value="Studio">Studio</SelectItem>
                        <SelectItem value="Loft">Loft</SelectItem>
                        <SelectItem value="Villa">Villa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="rooms">Nombre de pièces</Label>
                    <Select
                      value={propertyData.rooms}
                      onValueChange={(value) => setPropertyData((prev) => ({ ...prev, rooms: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="T1">T1</SelectItem>
                        <SelectItem value="T2">T2</SelectItem>
                        <SelectItem value="T3">T3</SelectItem>
                        <SelectItem value="T4">T4</SelectItem>
                        <SelectItem value="T5+">T5+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="surface">Surface (m²)</Label>
                    <Input
                      id="surface"
                      value={propertyData.surface}
                      onChange={(e) => setPropertyData((prev) => ({ ...prev, surface: e.target.value }))}
                      placeholder="85"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Prix (€)</Label>
                    <Input
                      id="price"
                      value={propertyData.price}
                      onChange={(e) => setPropertyData((prev) => ({ ...prev, price: e.target.value }))}
                      placeholder="285000"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <Input
                    id="location"
                    value={propertyData.location}
                    onChange={(e) => setPropertyData((prev) => ({ ...prev, location: e.target.value }))}
                    placeholder="Lyon 6ème"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description (optionnel)</Label>
                  <Textarea
                    id="description"
                    value={propertyData.description}
                    onChange={(e) => setPropertyData((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="Décrivez les points forts du bien..."
                    rows={3}
                  />
                </div>

                {/* Features */}
                <div>
                  <Label>Caractéristiques</Label>
                  <div className="flex flex-wrap gap-2 mt-2 mb-3">
                    {propertyData.features.map((feature) => (
                      <Badge
                        key={feature}
                        variant="secondary"
                        className="cursor-pointer"
                        onClick={() => removeFeature(feature)}
                      >
                        {feature} ×
                      </Badge>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {["Balcon", "Parking", "Cave", "Ascenseur", "Terrasse", "Jardin", "Piscine", "Cheminée"].map(
                      (feature) => (
                        <Button
                          key={feature}
                          variant="outline"
                          size="sm"
                          onClick={() => addFeature(feature)}
                          disabled={propertyData.features.includes(feature)}
                        >
                          {feature}
                        </Button>
                      ),
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Specific Options */}
            {contentType === "email" && (
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Type d'email</CardTitle>
                </CardHeader>
                <CardContent>
                  <Select value={emailType} onValueChange={setEmailType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner le type d'email" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prospection">Email de prospection</SelectItem>
                      <SelectItem value="relance">Email de relance</SelectItem>
                      <SelectItem value="visite">Confirmation de visite</SelectItem>
                      <SelectItem value="suivi">Email de suivi</SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            )}

            {contentType === "post" && (
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>Plateforme sociale</CardTitle>
                </CardHeader>
                <CardContent>
                  <Select value={postPlatform} onValueChange={setPostPlatform}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner la plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            )}

            {/* Tone Settings */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-slate-600" />
                  Ton de communication
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professionnel">Professionnel</SelectItem>
                    <SelectItem value="chaleureux">Chaleureux</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="moderne">Moderne</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !propertyData.type || !propertyData.location}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Génération en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Générer le contenu
                </>
              )}
            </Button>
          </div>

          {/* Preview */}
          <div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 h-full">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Aperçu du contenu</CardTitle>
                {generatedContent && (
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 mr-2" />
                        Copié !
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copier
                      </>
                    )}
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {!generatedContent ? (
                  <div className="flex items-center justify-center h-96 text-center">
                    <div>
                      <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                        <FileText className="w-8 h-8 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900 mb-2">Contenu généré</h3>
                      <p className="text-slate-600">
                        Remplissez les informations et cliquez sur "Générer" pour voir le résultat
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 rounded-lg p-6">
                    <pre className="whitespace-pre-wrap text-sm text-slate-800 font-mono leading-relaxed">
                      {generatedContent}
                    </pre>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
