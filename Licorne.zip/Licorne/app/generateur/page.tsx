"use client"

import { useState, useEffect, Suspense } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Sparkles, Eye, Code, Download, Share, RefreshCw, Save, Wand2, Copy, Check } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

function GeneratorContent() {
  const searchParams = useSearchParams()
  const initialPrompt = searchParams.get("prompt") || ""

  const [prompt, setPrompt] = useState(initialPrompt)
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedCode, setGeneratedCode] = useState("")
  const [generatedPreview, setGeneratedPreview] = useState("")
  const [projectName, setProjectName] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (initialPrompt) {
      handleGenerate()
    }
  }, [initialPrompt])

  const handleGenerate = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)

    // Simulate AI generation
    await new Promise((resolve) => setTimeout(resolve, 3000))

    // Mock generated code
    const mockCode = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salon de Coiffure - Élégance</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-pink-50 to-purple-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="max-w-6xl mx-auto px-6 py-4">
            <nav class="flex items-center justify-between">
                <h1 class="text-2xl font-bold text-purple-600">Salon Élégance</h1>
                <div class="flex items-center gap-6">
                    <a href="#services" class="text-gray-600 hover:text-purple-600">Services</a>
                    <a href="#equipe" class="text-gray-600 hover:text-purple-600">Équipe</a>
                    <a href="#contact" class="text-gray-600 hover:text-purple-600">Contact</a>
                    <button class="bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700">
                        Prendre RDV
                    </button>
                </div>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="py-20">
        <div class="max-w-6xl mx-auto px-6 text-center">
            <h2 class="text-5xl font-bold text-gray-900 mb-6">
                Révélez votre beauté naturelle
            </h2>
            <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Notre équipe d'experts vous accompagne pour sublimer votre style avec des techniques modernes et des produits de qualité.
            </p>
            <button class="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-lg transition-all">
                Réserver maintenant
            </button>
        </div>
    </section>

    <!-- Services -->
    <section id="services" class="py-16 bg-white">
        <div class="max-w-6xl mx-auto px-6">
            <h3 class="text-3xl font-bold text-center text-gray-900 mb-12">Nos Services</h3>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6 rounded-2xl bg-gradient-to-br from-purple-50 to-pink-50">
                    <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        ✂️
                    </div>
                    <h4 class="text-xl font-semibold mb-3">Coupe & Styling</h4>
                    <p class="text-gray-600">Coupes modernes et personnalisées selon votre style</p>
                    <p class="text-purple-600 font-semibold mt-4">À partir de 45€</p>
                </div>
                <div class="text-center p-6 rounded-2xl bg-gradient-to-br from-purple-50 to-pink-50">
                    <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        🎨
                    </div>
                    <h4 class="text-xl font-semibold mb-3">Coloration</h4>
                    <p class="text-gray-600">Colorations naturelles et techniques avancées</p>
                    <p class="text-purple-600 font-semibold mt-4">À partir de 65€</p>
                </div>
                <div class="text-center p-6 rounded-2xl bg-gradient-to-br from-purple-50 to-pink-50">
                    <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        💆‍♀️
                    </div>
                    <h4 class="text-xl font-semibold mb-3">Soins</h4>
                    <p class="text-gray-600">Traitements capillaires pour cheveux en santé</p>
                    <p class="text-purple-600 font-semibold mt-4">À partir de 35€</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>`

    setGeneratedCode(mockCode)
    setGeneratedPreview(mockCode)
    setProjectName("Salon de Coiffure - Accueil")
    setIsGenerating(false)
  }

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(generatedCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSaveProject = async () => {
    // Simulate saving
    await new Promise((resolve) => setTimeout(resolve, 1000))
    alert("Projet sauvegardé avec succès !")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b border-slate-200/60 bg-white/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link
                href="/dashboard"
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                Retour
              </Link>
              <div className="h-6 w-px bg-slate-300" />
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-slate-900">{projectName || "Nouveau projet"}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {generatedCode && (
                <>
                  <Button variant="outline" onClick={handleSaveProject}>
                    <Save className="w-4 h-4 mr-2" />
                    Sauvegarder
                  </Button>
                  <Button variant="outline">
                    <Share className="w-4 h-4 mr-2" />
                    Partager
                  </Button>
                  <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                    <Download className="w-4 h-4 mr-2" />
                    Exporter
                  </Button>
                </>
              )}
            </div>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-8 h-[calc(100vh-200px)]">
          {/* Left Panel - Prompt & Controls */}
          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-indigo-600" />
                  Description de votre projet
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Décrivez l'application que vous souhaitez créer..."
                  className="min-h-[120px] resize-none"
                />

                <div className="flex gap-3">
                  <Button
                    onClick={handleGenerate}
                    disabled={!prompt.trim() || isGenerating}
                    className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  >
                    {isGenerating ? (
                      <>
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        Génération...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Générer
                      </>
                    )}
                  </Button>

                  {generatedCode && (
                    <Button variant="outline" onClick={handleGenerate} disabled={isGenerating}>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Régénérer
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Generation Status */}
            {isGenerating && (
              <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200/60">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-6 h-6 text-indigo-600 animate-spin" />
                    <div>
                      <h3 className="font-semibold text-slate-900">Génération en cours...</h3>
                      <p className="text-slate-600 text-sm">L'IA analyse votre demande et génère le code</p>
                    </div>
                  </div>
                  <div className="mt-4 w-full bg-slate-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full animate-pulse"
                      style={{ width: "60%" }}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Assistant */}
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="text-lg">💡 Assistant IA</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 text-sm mb-4">
                  Besoin d'aide pour formuler votre demande ? Voici quelques suggestions :
                </p>
                <div className="space-y-2">
                  {[
                    "Ajouter plus de détails sur le style visuel",
                    "Préciser les fonctionnalités importantes",
                    "Mentionner le type d'utilisateurs cibles",
                  ].map((suggestion, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-left h-auto p-3 text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Preview & Code */}
          <div className="space-y-6">
            {!generatedCode ? (
              <Card className="bg-white/60 backdrop-blur-sm border-slate-200/60 h-full flex items-center justify-center">
                <CardContent className="text-center p-12">
                  <div className="w-20 h-20 bg-slate-100 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                    <Eye className="w-10 h-10 text-slate-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Aperçu de votre projet</h3>
                  <p className="text-slate-600">Décrivez votre projet pour voir l'aperçu généré par l'IA</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 h-full">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Résultat généré</CardTitle>
                    <Badge className="bg-green-50 text-green-700 border-green-200">✓ Terminé</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0 h-[calc(100%-80px)]">
                  <Tabs defaultValue="preview" className="h-full flex flex-col">
                    <TabsList className="mx-6 mb-4">
                      <TabsTrigger value="preview" className="flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        Aperçu
                      </TabsTrigger>
                      <TabsTrigger value="code" className="flex items-center gap-2">
                        <Code className="w-4 h-4" />
                        Code
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="preview" className="flex-1 mx-6 mb-6">
                      <div className="h-full bg-white rounded-lg border border-slate-200 overflow-hidden">
                        <iframe srcDoc={generatedPreview} className="w-full h-full" title="Aperçu du projet" />
                      </div>
                    </TabsContent>

                    <TabsContent value="code" className="flex-1 mx-6 mb-6">
                      <div className="h-full bg-slate-900 rounded-lg overflow-hidden">
                        <div className="flex items-center justify-between p-4 border-b border-slate-700">
                          <span className="text-slate-300 text-sm font-mono">index.html</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleCopyCode}
                            className="text-slate-300 hover:text-white hover:bg-slate-700"
                          >
                            {copied ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copié !
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copier
                              </>
                            )}
                          </Button>
                        </div>
                        <pre className="p-4 text-sm text-slate-300 overflow-auto h-[calc(100%-60px)] font-mono">
                          <code>{generatedCode}</code>
                        </pre>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function GeneratorPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center">
          <div className="text-center">
            <Sparkles className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-4" />
            <p className="text-slate-600">Chargement du générateur...</p>
          </div>
        </div>
      }
    >
      <GeneratorContent />
    </Suspense>
  )
}
