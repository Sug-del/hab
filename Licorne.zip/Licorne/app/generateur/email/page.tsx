"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Sparkles, Copy, Check, Save, Mail, Send } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

interface EmailData {
  type: string
  targetAudience: string
  location: string
  propertyType: string
  objective: string
  personalInfo: string
  tone: string
}

export default function EmailGeneratorPage() {
  const [emailData, setEmailData] = useState<EmailData>({
    type: "",
    targetAudience: "",
    location: "",
    propertyType: "",
    objective: "",
    personalInfo: "",
    tone: "professionnel",
  })

  const [generatedEmail, setGeneratedEmail] = useState({
    subject: "",
    content: "",
  })

  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState("")

  const handleGenerate = async () => {
    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(emailData),
      })

      const data = await response.json()

      if (data.success) {
        setGeneratedEmail(data.email)
      }
    } catch (error) {
      console.error("Erreur lors de la génération:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = async (content: string, type: string) => {
    await navigator.clipboard.writeText(content)
    setCopied(type)
    setTimeout(() => setCopied(""), 2000)
  }

  const handleCopyAll = async () => {
    const fullEmail = `Objet: ${generatedEmail.subject}\n\n${generatedEmail.content}`
    await navigator.clipboard.writeText(fullEmail)
    setCopied("all")
    setTimeout(() => setCopied(""), 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Générateur d'emails de prospection</h1>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Formulaire */}
          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-green-600" />
                  Configuration de l'email
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="type">Type d'email</Label>
                  <Select
                    value={emailData.type}
                    onValueChange={(value) => setEmailData((prev) => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir le type d'email" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prospection-vendeur">Prospection vendeur</SelectItem>
                      <SelectItem value="prospection-acheteur">Prospection acheteur</SelectItem>
                      <SelectItem value="relance">Email de relance</SelectItem>
                      <SelectItem value="estimation">Proposition d'estimation</SelectItem>
                      <SelectItem value="suivi">Email de suivi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="targetAudience">Public cible</Label>
                  <Select
                    value={emailData.targetAudience}
                    onValueChange={(value) => setEmailData((prev) => ({ ...prev, targetAudience: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Qui voulez-vous cibler ?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="proprietaires">Propriétaires</SelectItem>
                      <SelectItem value="investisseurs">Investisseurs</SelectItem>
                      <SelectItem value="primo-accedants">Primo-accédants</SelectItem>
                      <SelectItem value="seniors">Seniors</SelectItem>
                      <SelectItem value="familles">Familles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="location">Zone géographique</Label>
                    <Input
                      id="location"
                      value={emailData.location}
                      onChange={(e) => setEmailData((prev) => ({ ...prev, location: e.target.value }))}
                      placeholder="Lyon 6ème, Villeurbanne..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="propertyType">Type de bien</Label>
                    <Input
                      id="propertyType"
                      value={emailData.propertyType}
                      onChange={(e) => setEmailData((prev) => ({ ...prev, propertyType: e.target.value }))}
                      placeholder="Appartements, maisons..."
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="objective">Objectif principal</Label>
                  <Select
                    value={emailData.objective}
                    onValueChange={(value) => setEmailData((prev) => ({ ...prev, objective: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Quel est votre objectif ?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="obtenir-mandat">Obtenir un mandat de vente</SelectItem>
                      <SelectItem value="rdv-estimation">Prendre RDV pour estimation</SelectItem>
                      <SelectItem value="presenter-bien">Présenter un bien</SelectItem>
                      <SelectItem value="generer-lead">Générer un lead</SelectItem>
                      <SelectItem value="fidéliser">Fidéliser un client</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="personalInfo">Informations personnelles</Label>
                  <Textarea
                    id="personalInfo"
                    value={emailData.personalInfo}
                    onChange={(e) => setEmailData((prev) => ({ ...prev, personalInfo: e.target.value }))}
                    placeholder="Votre nom, agence, spécialités, années d'expérience..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="tone">Ton de communication</Label>
                  <Select
                    value={emailData.tone}
                    onValueChange={(value) => setEmailData((prev) => ({ ...prev, tone: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professionnel">Professionnel</SelectItem>
                      <SelectItem value="chaleureux">Chaleureux</SelectItem>
                      <SelectItem value="direct">Direct</SelectItem>
                      <SelectItem value="conseil">Conseil/Expert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !emailData.type || !emailData.location}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Génération en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Générer l'email
                </>
              )}
            </Button>
          </div>

          {/* Résultat */}
          <div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 h-full">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Email généré</CardTitle>
                {generatedEmail.content && (
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleCopyAll}>
                      {copied === "all" ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copié !
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copier tout
                        </>
                      )}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Save className="w-4 h-4 mr-2" />
                      Sauvegarder
                    </Button>
                    <Button variant="outline" size="sm">
                      <Send className="w-4 h-4 mr-2" />
                      Envoyer
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {!generatedEmail.content ? (
                  <div className="flex items-center justify-center h-96 text-center">
                    <div>
                      <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                        <Mail className="w-8 h-8 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900 mb-2">Votre email apparaîtra ici</h3>
                      <p className="text-slate-600">Configurez votre email et cliquez sur "Générer"</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Objet de l'email */}
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Label className="font-semibold">Objet :</Label>
                        <Button variant="ghost" size="sm" onClick={() => handleCopy(generatedEmail.subject, "subject")}>
                          {copied === "subject" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      </div>
                      <div className="bg-blue-50 rounded-lg p-3">
                        <p className="text-sm font-medium text-slate-800">{generatedEmail.subject}</p>
                      </div>
                    </div>

                    {/* Contenu de l'email */}
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Label className="font-semibold">Contenu :</Label>
                        <Button variant="ghost" size="sm" onClick={() => handleCopy(generatedEmail.content, "content")}>
                          {copied === "content" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      </div>
                      <div className="bg-slate-50 rounded-lg p-4">
                        <pre className="whitespace-pre-wrap text-sm text-slate-800 leading-relaxed">
                          {generatedEmail.content}
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
