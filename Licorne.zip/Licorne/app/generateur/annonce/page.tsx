"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Sparkles, Copy, Check, Save, Eye, Wand2 } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

// Interface pour les données du bien immobilier
interface PropertyData {
  type: string
  surface: string
  rooms: string
  price: string
  location: string
  description: string
  features: string[]
}

export default function AnnonceGeneratorPage() {
  const [propertyData, setPropertyData] = useState<PropertyData>({
    type: "",
    surface: "",
    rooms: "",
    price: "",
    location: "",
    description: "",
    features: [],
  })

  const [generatedAnnonce, setGeneratedAnnonce] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState(false)

  // Fonction pour générer l'annonce avec l'IA
  const handleGenerate = async () => {
    setIsGenerating(true)

    try {
      // Appel à notre API route qui utilise OpenAI
      const response = await fetch("/api/generate-annonce", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(propertyData),
      })

      const data = await response.json()

      if (data.success) {
        setGeneratedAnnonce(data.annonce)
      } else {
        console.error("Erreur:", data.error)
      }
    } catch (error) {
      console.error("Erreur lors de la génération:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  // Fonction pour copier le texte
  const handleCopy = async () => {
    await navigator.clipboard.writeText(generatedAnnonce)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Fonction pour ajouter/retirer des caractéristiques
  const toggleFeature = (feature: string) => {
    setPropertyData((prev) => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter((f) => f !== feature)
        : [...prev.features, feature],
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Générateur d'annonces IA</h1>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Formulaire de saisie */}
          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-blue-600" />
                  Informations du bien
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="type">Type de bien</Label>
                    <Select
                      value={propertyData.type}
                      onValueChange={(value) => setPropertyData((prev) => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="appartement">Appartement</SelectItem>
                        <SelectItem value="maison">Maison</SelectItem>
                        <SelectItem value="studio">Studio</SelectItem>
                        <SelectItem value="loft">Loft</SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="rooms">Nombre de pièces</Label>
                    <Select
                      value={propertyData.rooms}
                      onValueChange={(value) => setPropertyData((prev) => ({ ...prev, rooms: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="T1">T1</SelectItem>
                        <SelectItem value="T2">T2</SelectItem>
                        <SelectItem value="T3">T3</SelectItem>
                        <SelectItem value="T4">T4</SelectItem>
                        <SelectItem value="T5+">T5+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="surface">Surface (m²)</Label>
                    <Input
                      id="surface"
                      value={propertyData.surface}
                      onChange={(e) => setPropertyData((prev) => ({ ...prev, surface: e.target.value }))}
                      placeholder="85"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Prix (€)</Label>
                    <Input
                      id="price"
                      value={propertyData.price}
                      onChange={(e) => setPropertyData((prev) => ({ ...prev, price: e.target.value }))}
                      placeholder="285000"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <Input
                    id="location"
                    value={propertyData.location}
                    onChange={(e) => setPropertyData((prev) => ({ ...prev, location: e.target.value }))}
                    placeholder="Lyon 6ème, proche métro"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description complémentaire</Label>
                  <Textarea
                    id="description"
                    value={propertyData.description}
                    onChange={(e) => setPropertyData((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="Points forts du bien, rénovations récentes, environnement..."
                    rows={3}
                  />
                </div>

                {/* Caractéristiques */}
                <div>
                  <Label>Caractéristiques</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {["Balcon", "Terrasse", "Parking", "Cave", "Ascenseur", "Jardin", "Piscine", "Cheminée"].map(
                      (feature) => (
                        <Badge
                          key={feature}
                          variant={propertyData.features.includes(feature) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => toggleFeature(feature)}
                        >
                          {feature}
                        </Badge>
                      ),
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !propertyData.type || !propertyData.location}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Génération en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Générer l'annonce IA
                </>
              )}
            </Button>
          </div>

          {/* Aperçu du résultat */}
          <div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 h-full">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Annonce générée</CardTitle>
                {generatedAnnonce && (
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleCopy}>
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copié !
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copier
                        </>
                      )}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Save className="w-4 h-4 mr-2" />
                      Sauvegarder
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {!generatedAnnonce ? (
                  <div className="flex items-center justify-center h-96 text-center">
                    <div>
                      <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                        <Eye className="w-8 h-8 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900 mb-2">Votre annonce apparaîtra ici</h3>
                      <p className="text-slate-600">Remplissez les informations du bien et cliquez sur "Générer"</p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 rounded-lg p-6">
                    <pre className="whitespace-pre-wrap text-sm text-slate-800 leading-relaxed">{generatedAnnonce}</pre>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
