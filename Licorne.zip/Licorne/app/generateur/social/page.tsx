"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Sparkles, Copy, Check, Users, Instagram, Linkedin, Video } from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

interface SocialData {
  platform: string
  propertyType: string
  location: string
  price: string
  hook: string
  callToAction: string
  tone: string
}

export default function SocialGeneratorPage() {
  const [socialData, setSocialData] = useState<SocialData>({
    platform: "",
    propertyType: "",
    location: "",
    price: "",
    hook: "",
    callToAction: "",
    tone: "professionnel",
  })

  const [generatedContent, setGeneratedContent] = useState({
    linkedin: "",
    instagram: "",
    tiktok: "",
  })

  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState("")

  const handleGenerate = async () => {
    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-social", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(socialData),
      })

      const data = await response.json()

      if (data.success) {
        setGeneratedContent(data.content)
      }
    } catch (error) {
      console.error("Erreur lors de la génération:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = async (content: string, platform: string) => {
    await navigator.clipboard.writeText(content)
    setCopied(platform)
    setTimeout(() => setCopied(""), 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">Générateur de contenu social</h1>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Formulaire */}
          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Configuration du contenu
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="platform">Plateforme principale</Label>
                  <Select
                    value={socialData.platform}
                    onValueChange={(value) => setSocialData((prev) => ({ ...prev, platform: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir une plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                      <SelectItem value="all">Toutes les plateformes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="propertyType">Type de bien</Label>
                    <Input
                      id="propertyType"
                      value={socialData.propertyType}
                      onChange={(e) => setSocialData((prev) => ({ ...prev, propertyType: e.target.value }))}
                      placeholder="Appartement T3"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Prix</Label>
                    <Input
                      id="price"
                      value={socialData.price}
                      onChange={(e) => setSocialData((prev) => ({ ...prev, price: e.target.value }))}
                      placeholder="285 000€"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <Input
                    id="location"
                    value={socialData.location}
                    onChange={(e) => setSocialData((prev) => ({ ...prev, location: e.target.value }))}
                    placeholder="Lyon 6ème"
                  />
                </div>

                <div>
                  <Label htmlFor="hook">Accroche personnalisée (optionnel)</Label>
                  <Input
                    id="hook"
                    value={socialData.hook}
                    onChange={(e) => setSocialData((prev) => ({ ...prev, hook: e.target.value }))}
                    placeholder="🏠 Coup de cœur de la semaine !"
                  />
                </div>

                <div>
                  <Label htmlFor="callToAction">Call-to-action</Label>
                  <Select
                    value={socialData.callToAction}
                    onValueChange={(value) => setSocialData((prev) => ({ ...prev, callToAction: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir un CTA" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="visite">Demander une visite</SelectItem>
                      <SelectItem value="contact">Me contacter</SelectItem>
                      <SelectItem value="info">Plus d'informations</SelectItem>
                      <SelectItem value="estimation">Estimation gratuite</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="tone">Ton de communication</Label>
                  <Select
                    value={socialData.tone}
                    onValueChange={(value) => setSocialData((prev) => ({ ...prev, tone: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professionnel">Professionnel</SelectItem>
                      <SelectItem value="chaleureux">Chaleureux</SelectItem>
                      <SelectItem value="dynamique">Dynamique</SelectItem>
                      <SelectItem value="premium">Premium</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !socialData.propertyType || !socialData.location}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-6 text-lg"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Génération en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Générer le contenu
                </>
              )}
            </Button>
          </div>

          {/* Résultats */}
          <div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 h-full">
              <CardHeader>
                <CardTitle>Contenu généré</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="linkedin" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="linkedin" className="flex items-center gap-2">
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </TabsTrigger>
                    <TabsTrigger value="instagram" className="flex items-center gap-2">
                      <Instagram className="w-4 h-4" />
                      Instagram
                    </TabsTrigger>
                    <TabsTrigger value="tiktok" className="flex items-center gap-2">
                      <Video className="w-4 h-4" />
                      TikTok
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="linkedin" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="font-semibold">Post LinkedIn</h3>
                        {generatedContent.linkedin && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCopy(generatedContent.linkedin, "linkedin")}
                          >
                            {copied === "linkedin" ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copié !
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copier
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                      <div className="bg-slate-50 rounded-lg p-4 min-h-[200px]">
                        {generatedContent.linkedin ? (
                          <pre className="whitespace-pre-wrap text-sm text-slate-800">{generatedContent.linkedin}</pre>
                        ) : (
                          <p className="text-slate-500 text-center py-8">
                            Le contenu LinkedIn apparaîtra ici après génération
                          </p>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="instagram" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="font-semibold">Post Instagram</h3>
                        {generatedContent.instagram && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCopy(generatedContent.instagram, "instagram")}
                          >
                            {copied === "instagram" ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copié !
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copier
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                      <div className="bg-slate-50 rounded-lg p-4 min-h-[200px]">
                        {generatedContent.instagram ? (
                          <pre className="whitespace-pre-wrap text-sm text-slate-800">{generatedContent.instagram}</pre>
                        ) : (
                          <p className="text-slate-500 text-center py-8">
                            Le contenu Instagram apparaîtra ici après génération
                          </p>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="tiktok" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="font-semibold">Script TikTok</h3>
                        {generatedContent.tiktok && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCopy(generatedContent.tiktok, "tiktok")}
                          >
                            {copied === "tiktok" ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copié !
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copier
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                      <div className="bg-slate-50 rounded-lg p-4 min-h-[200px]">
                        {generatedContent.tiktok ? (
                          <pre className="whitespace-pre-wrap text-sm text-slate-800">{generatedContent.tiktok}</pre>
                        ) : (
                          <p className="text-slate-500 text-center py-8">
                            Le script TikTok apparaîtra ici après génération
                          </p>
                        )}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
