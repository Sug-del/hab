"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  Play,
  Pause,
  Settings,
  Zap,
  Clock,
  CheckCircle,
  AlertCircle,
  Home,
  FileText,
  MessageSquare,
  Share2,
  ArrowRight,
  MoreHorizontal,
} from "lucide-react"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"

interface Workflow {
  id: string
  name: string
  description: string
  status: "active" | "paused" | "draft"
  triggers: number
  completions: number
  lastRun: string
  steps: WorkflowStep[]
}

interface WorkflowStep {
  id: string
  type: "trigger" | "generate" | "send" | "wait"
  name: string
  icon: any
  status: "completed" | "running" | "pending" | "error"
}

export default function WorkflowsPage() {
  const [workflows] = useState<Workflow[]>([
    {
      id: "1",
      name: "Nouveau bien → Diffusion complète",
      description: "Génère automatiquement annonce, email et post social lors de l'ajout d'un nouveau bien",
      status: "active",
      triggers: 12,
      completions: 11,
      lastRun: "2024-01-16T14:30:00Z",
      steps: [
        { id: "1", type: "trigger", name: "Nouveau bien ajouté", icon: Home, status: "completed" },
        { id: "2", type: "generate", name: "Générer annonce", icon: FileText, status: "completed" },
        { id: "3", type: "generate", name: "Générer email prospect", icon: MessageSquare, status: "completed" },
        { id: "4", type: "generate", name: "Générer post LinkedIn", icon: Share2, status: "running" },
        { id: "5", type: "send", name: "Envoyer notifications", icon: Zap, status: "pending" },
      ],
    },
    {
      id: "2",
      name: "Relance leads inactifs",
      description: "Envoie automatiquement un email de relance aux leads sans activité depuis 7 jours",
      status: "active",
      triggers: 8,
      completions: 8,
      lastRun: "2024-01-15T09:00:00Z",
      steps: [
        { id: "1", type: "trigger", name: "Lead inactif 7j", icon: Clock, status: "completed" },
        { id: "2", type: "generate", name: "Email de relance", icon: MessageSquare, status: "completed" },
        { id: "3", type: "send", name: "Envoyer email", icon: Zap, status: "completed" },
      ],
    },
    {
      id: "3",
      name: "Suivi post-visite",
      description: "Envoie un email de suivi personnalisé 24h après chaque visite programmée",
      status: "paused",
      triggers: 5,
      completions: 3,
      lastRun: "2024-01-14T16:45:00Z",
      steps: [
        { id: "1", type: "trigger", name: "Visite terminée", icon: Home, status: "completed" },
        { id: "2", type: "wait", name: "Attendre 24h", icon: Clock, status: "completed" },
        { id: "3", type: "generate", name: "Email de suivi", icon: MessageSquare, status: "error" },
        { id: "4", type: "send", name: "Envoyer email", icon: Zap, status: "pending" },
      ],
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-700 border-green-200"
      case "paused":
        return "bg-yellow-100 text-yellow-700 border-yellow-200"
      case "draft":
        return "bg-slate-100 text-slate-700 border-slate-200"
      default:
        return "bg-slate-100 text-slate-700 border-slate-200"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Actif"
      case "paused":
        return "En pause"
      case "draft":
        return "Brouillon"
      default:
        return status
    }
  }

  const getStepStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600"
      case "running":
        return "text-blue-600"
      case "error":
        return "text-red-600"
      default:
        return "text-slate-400"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <DashboardHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Workflows automatisés</h1>
            <p className="text-slate-600">Automatisez vos tâches répétitives et gagnez du temps</p>
          </div>
          <Link href="/workflows/nouveau">
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau workflow
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Workflows actifs</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {workflows.filter((w) => w.status === "active").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Zap className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Exécutions ce mois</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {workflows.reduce((sum, w) => sum + w.triggers, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Play className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Taux de réussite</p>
                  <p className="text-2xl font-bold text-slate-900">92%</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Temps économisé</p>
                  <p className="text-2xl font-bold text-slate-900">15h</p>
                  <p className="text-xs text-green-600">Ce mois-ci</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Workflows List */}
        <div className="space-y-6">
          {workflows.map((workflow) => (
            <Card
              key={workflow.id}
              className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-semibold text-slate-900">{workflow.name}</CardTitle>
                      <p className="text-sm text-slate-600 mt-1">{workflow.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={getStatusColor(workflow.status)}>{getStatusLabel(workflow.status)}</Badge>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                {/* Workflow Steps */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-slate-900 mb-3">Étapes du workflow</h4>
                  <div className="flex items-center gap-2 overflow-x-auto pb-2">
                    {workflow.steps.map((step, index) => (
                      <div key={step.id} className="flex items-center gap-2 shrink-0">
                        <div
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
                            step.status === "completed"
                              ? "bg-green-50 border-green-200"
                              : step.status === "running"
                                ? "bg-blue-50 border-blue-200"
                                : step.status === "error"
                                  ? "bg-red-50 border-red-200"
                                  : "bg-slate-50 border-slate-200"
                          }`}
                        >
                          <step.icon className={`w-4 h-4 ${getStepStatusColor(step.status)}`} />
                          <span className={`text-sm font-medium ${getStepStatusColor(step.status)}`}>{step.name}</span>
                          {step.status === "running" && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                          )}
                          {step.status === "error" && <AlertCircle className="w-4 h-4 text-red-500" />}
                        </div>
                        {index < workflow.steps.length - 1 && <ArrowRight className="w-4 h-4 text-slate-400" />}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stats & Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6 text-sm text-slate-600">
                    <div>
                      <span className="font-medium">{workflow.triggers}</span> déclenchements
                    </div>
                    <div>
                      <span className="font-medium">{workflow.completions}</span> complétés
                    </div>
                    <div>Dernière exécution : {new Date(workflow.lastRun).toLocaleDateString("fr-FR")}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    {workflow.status === "active" ? (
                      <Button variant="outline" size="sm">
                        <Pause className="w-4 h-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm">
                        <Play className="w-4 h-4 mr-2" />
                        Activer
                      </Button>
                    )}
                    <Button variant="outline" size="sm">
                      <Settings className="w-4 h-4 mr-2" />
                      Configurer
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Templates Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Modèles de workflows</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                name: "Accueil nouveau client",
                description: "Séquence d'emails automatique pour accueillir un nouveau client",
                icon: MessageSquare,
                color: "from-blue-500 to-cyan-500",
              },
              {
                name: "Suivi après signature",
                description: "Workflow de suivi post-signature avec documents et félicitations",
                icon: CheckCircle,
                color: "from-green-500 to-emerald-500",
              },
              {
                name: "Relance prospects froids",
                description: "Réactivation automatique des prospects inactifs depuis 30 jours",
                icon: Clock,
                color: "from-orange-500 to-red-500",
              },
            ].map((template, index) => (
              <Card
                key={index}
                className="bg-white/60 backdrop-blur-sm border-slate-200/60 hover:shadow-lg transition-all cursor-pointer"
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-16 h-16 bg-gradient-to-r ${template.color} rounded-2xl flex items-center justify-center mb-4 mx-auto`}
                  >
                    <template.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">{template.name}</h3>
                  <p className="text-sm text-slate-600 mb-4">{template.description}</p>
                  <Button variant="outline" size="sm" className="w-full">
                    Utiliser ce modèle
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
