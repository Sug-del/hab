-- Insert demo users
INSERT INTO users (id, email, name, subscription_type, content_generated, content_limit) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'sophie@agence.fr', 'Sophie Martineau', 'pro', 47, 999999),
('550e8400-e29b-41d4-a716-446655440001', 'marc@orpi.fr', 'Marc Dubois', 'pro', 78, 999999),
('550e8400-e29b-41d4-a716-446655440002', 'julie@gmail.com', 'Julie Leroy', 'starter', 12, 50),
('marie@example.com', 'free', 'Marie Dupont', 3, 5),
('thomas@example.com', 'pro', 'Thomas Bernard', 15, 999),
('alex@example.com', 'pro', 'Alexandre Dubois', 8, 999),
('julie@example.com', 'free', 'Julie Moreau', 1, 5),
('pierre@example.com', 'free', 'Pierre Martin', 4, 5);

-- Insert demo projects
INSERT INTO projects (user_id, name, prompt, generated_code, status, is_public, likes_count) VALUES
(1, 'Restaurant Moderne', 'Une page d''accueil élégante pour un restaurant gastronomique avec menu interactif et réservations', '<html>...</html>', 'completed', true, 124),
(2, 'Dashboard SaaS', 'Interface d''administration complète avec graphiques, métriques et gestion d''utilisateurs', '<html>...</html>', 'completed', true, 89),
(3, 'Portfolio Créatif', 'Site portfolio moderne pour designer avec galerie interactive et animations fluides', '<html>...</html>', 'completed', true, 156),
(4, 'E-commerce Mode', 'Boutique en ligne pour vêtements avec catalogue produits et panier d''achat', '<html>...</html>', 'completed', true, 203),
(5, 'App Fitness', 'Application de fitness avec suivi d''entraînements et programmes personnalisés', '<html>...</html>', 'completed', true, 78),
(6, 'Agence Immobilière', 'Site d''agence immobilière avec recherche de biens et visites virtuelles', '<html>...</html>', 'completed', true, 92);

-- Insert project tags
INSERT INTO project_tags (project_id, tag) VALUES
(1, 'Restaurant'), (1, 'Réservation'), (1, 'Menu'),
(2, 'SaaS'), (2, 'Analytics'), (2, 'Admin'),
(3, 'Portfolio'), (3, 'Design'), (3, 'Créatif'),
(4, 'E-commerce'), (4, 'Mode'), (4, 'Boutique'),
(5, 'Fitness'), (5, 'Sport'), (5, 'Santé'),
(6, 'Immobilier'), (6, 'Recherche'), (6, 'Visite');

-- Insert demo content
INSERT INTO content (user_id, type, platform, title, content, status, engagement) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'annonce', NULL, 'Appartement T3 lumineux - Lyon 6ème', '🏠 COUP DE CŒUR - Appartement T3 de 85m² dans le prestigieux 6ème arrondissement...', 'published', '{"views": 245, "clicks": 23, "shares": 5}'),
('550e8400-e29b-41d4-a716-446655440000', 'social', 'linkedin', 'Post LinkedIn - Conseils investissement', '💡 5 conseils pour réussir votre premier investissement immobilier...', 'published', '{"views": 1250, "clicks": 89, "shares": 12}'),
('550e8400-e29b-41d4-a716-446655440000', 'email', NULL, 'Email prospection secteur Villeurbanne', 'Objet: Votre projet immobilier à Villeurbanne\n\nBonjour...', 'published', '{"views": 156, "clicks": 34, "shares": 0}'),
('550e8400-e29b-41d4-a716-446655440000', 'social', 'instagram', 'Story Instagram - Visite virtuelle', '🏡 Découvrez cette magnifique maison en visite virtuelle...', 'scheduled', NULL),
('550e8400-e29b-41d4-a716-446655440000', 'annonce', NULL, 'Maison familiale avec jardin', 'Charmante maison familiale de 140m² avec jardin arboré...', 'draft', NULL);

-- Insert demo calendar events
INSERT INTO calendar_events (user_id, content_id, title, date, time, status) VALUES
('550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000', 'Post LinkedIn', '2024-01-16', '14:00', 'scheduled'),
('550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000', 'Email prospection', '2024-01-17', '09:00', 'scheduled'),
('550e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000', 'Story Instagram', '2024-01-18', '16:00', 'draft');
