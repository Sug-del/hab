// CHECKLIST DE LANCEMENT - À EXÉCUTER CETTE SEMAINE

export const LAUNCH_CHECKLIST = {
  // JOUR 1-2 : OPTIMISATIONS TECHNIQUES
  technical: [
    "✅ Ajouter Google Analytics + Hotjar",
    "✅ Créer pages légales (CGU, Confidentialité, Mentions)",
    "✅ Optimiser SEO (meta, sitemap, robots.txt)",
    "✅ Tester tous les parcours utilisateur",
    "✅ Configurer emails transactionnels (Resend/SendGrid)",
  ],

  // JOUR 3 : PRÉPARATION COMMERCIALE
  commercial: [
    "✅ Créer deck de présentation (10 slides max)",
    "✅ Préparer démo de 5 minutes",
    "✅ Lister 500 prospects (agents immobiliers)",
    "✅ Créer templates emails de prospection",
    "✅ Configurer CRM simple (Notion/Airtable)",
  ],

  // JOUR 4-5 : PREMIERS CONTACTS
  prospection: [
    "✅ Contacter 50 prospects par jour",
    "✅ Programmer 10 démos par jour",
    "✅ Suivre taux de conversion",
    "✅ Itérer sur le pitch",
    "✅ Collecter feedback utilisateurs",
  ],
}

// OBJECTIF SEMAINE 1 : 10 clients signés
export const WEEK_1_TARGET = {
  prospects_contacted: 250,
  demos_scheduled: 50,
  demos_completed: 30,
  clients_signed: 10,
  mrr_generated: 1490, // 10 × 149€
}
