-- Index pour performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_subscription ON users(subscription_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_user_created ON generated_content(user_id, created_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_type ON generated_content(content_type);

-- Contraintes de sécurité
ALTER TABLE users ADD CONSTRAINT check_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
ALTER TABLE generated_content ADD CONSTRAINT check_content_length CHECK (char_length(content) <= 50000);

-- Backup automatique (à configurer côté Supabase)
-- Rétention des données
CREATE OR REPLACE FUNCTION cleanup_old_content() RETURNS void AS $$
BEGIN
  DELETE FROM generated_content 
  WHERE created_at < NOW() - INTERVAL '1 year' 
  AND user_id NOT IN (SELECT id FROM users WHERE subscription_type = 'pro');
END;
$$ LANGUAGE plpgsql;

-- Statistiques pour monitoring
CREATE OR REPLACE VIEW user_stats AS
SELECT 
  DATE_TRUNC('day', created_at) as date,
  COUNT(*) as daily_signups,
  COUNT(*) FILTER (WHERE subscription_type != 'free') as paid_signups
FROM users 
GROUP BY DATE_TRUNC('day', created_at)
ORDER BY date DESC;
