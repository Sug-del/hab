-- Insert demo users
INSERT INTO users (email, name, subscription_type, content_generated, content_limit) VALUES
('sophie.martineau@agence.fr', 'Sophie Martineau', 'pro', 45, 999),
('marc.dubois@orpi.fr', 'Marc Dubois', 'pro', 78, 999),
('julie.leroy@gmail.com', 'Julie Leroy', 'free', 12, 50);

-- Insert demo properties
INSERT INTO properties (user_id, title, type, rooms, surface, price, location, description, features, status, views, leads) VALUES
(1, 'Appartement T3 lumineux avec balcon', 'Appartement', 'T3', 85, 285000, 'Lyon 6ème', 'Magnifique appartement rénové avec goût, très lumineux grâce à son exposition sud. Balcon avec vue dégagée.', ARRAY['Balcon', 'Ascenseur', 'Parking'], 'active', 124, 8),
(1, 'Maison familiale avec jardin', 'Maison', 'T5', 140, 450000, 'Villeurbanne', 'Belle maison familiale avec jardin arboré, idéale pour une famille. Proche écoles et transports.', ARRAY['Jardin', 'Garage', 'Terrasse'], 'pending', 89, 12),
(1, 'Studio moderne centre-ville', 'Studio', 'T1', 32, 165000, 'Lyon 2ème', 'Studio entièrement rénové en plein centre-ville. Parfait pour investissement locatif.', ARRAY['Ascenseur', 'Proche métro'], 'sold', 67, 5),
(2, 'Loft industriel rénové', 'Loft', 'T4', 120, 380000, 'Lyon 1er', 'Magnifique loft dans ancienne usine rénovée. Volumes exceptionnels et cachet industriel préservé.', ARRAY['Terrasse', 'Parking', 'Cave'], 'active', 156, 15),
(3, 'Villa avec piscine', 'Villa', 'T6', 200, 750000, 'Caluire-et-Cuire', 'Superbe villa contemporaine avec piscine et vue panoramique sur Lyon.', ARRAY['Piscine', 'Jardin', 'Garage'], 'draft', 23, 2);

-- Insert demo leads
INSERT INTO leads (user_id, property_id, name, email, phone, interest, status, last_contact) VALUES
(1, 1, 'Marie Dubois', 'marie.dubois@email.com', '06 12 34 56 78', 'Appartement T3 lumineux', 'qualified', '2024-01-16 14:30:00'),
(1, 2, 'Thomas Martin', 'thomas.martin@email.com', '06 98 76 54 32', 'Maison familiale', 'new', '2024-01-15 09:00:00'),
(1, 1, 'Claire Rousseau', 'claire.rousseau@email.com', '06 55 44 33 22', 'Appartement T3 lumineux', 'contacted', '2024-01-14 16:45:00'),
(2, 4, 'Pierre Durand', 'pierre.durand@email.com', '06 77 88 99 00', 'Loft industriel', 'qualified', '2024-01-13 11:20:00');

-- Insert demo generated content
INSERT INTO generated_content (user_id, property_id, content_type, platform, content, tone) VALUES
(1, 1, 'annonce', NULL, '🏠 Appartement T3 lumineux - Lyon 6ème\n\n💰 Prix : 285000€\n📐 Surface : 85m²\n\n✨ Description :\nMagnifique appartement rénové avec goût...', 'professionnel'),
(1, 1, 'email', NULL, 'Objet : Votre projet immobilier à Lyon 6ème\n\nBonjour,\n\nJ''espère que vous allez bien...', 'chaleureux'),
(1, 2, 'post', 'linkedin', '🏠 Nouvelle opportunité immobilière à Villeurbanne !\n\nJe suis ravie de vous présenter...', 'professionnel');

-- Insert demo workflows
INSERT INTO workflows (user_id, name, description, status, triggers, completions, last_run) VALUES
(1, 'Nouveau bien → Diffusion complète', 'Génère automatiquement annonce, email et post social lors de l''ajout d''un nouveau bien', 'active', 12, 11, '2024-01-16 14:30:00'),
(1, 'Relance leads inactifs', 'Envoie automatiquement un email de relance aux leads sans activité depuis 7 jours', 'active', 8, 8, '2024-01-15 09:00:00'),
(1, 'Suivi post-visite', 'Envoie un email de suivi personnalisé 24h après chaque visite programmée', 'paused', 5, 3, '2024-01-14 16:45:00');

-- Insert demo workflow executions
INSERT INTO workflow_executions (workflow_id, property_id, status, steps_completed, total_steps, started_at, completed_at) VALUES
(1, 1, 'completed', 5, 5, '2024-01-16 14:30:00', '2024-01-16 14:35:00'),
(1, 2, 'running', 3, 5, '2024-01-16 15:00:00', NULL),
(2, NULL, 'completed', 3, 3, '2024-01-15 09:00:00', '2024-01-15 09:02:00');
