-- ============================================
-- PRODUCTION DATABASE SCHEMA - ENTERPRISE GRADE
-- ============================================

-- Extensions nécessaires
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================
-- TABLES PRINCIPALES
-- ============================================

-- Users table avec colonnes avancées
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  avatar_url TEXT,
  
  -- Subscription info
  subscription_type VARCHAR(20) DEFAULT 'free' CHECK (subscription_type IN ('free', 'starter', 'pro', 'agence')),
  subscription_status VARCHAR(20) DEFAULT 'active' CHECK (subscription_status IN ('active', 'canceled', 'past_due', 'unpaid')),
  content_limit INTEGER DEFAULT 50,
  monthly_usage INTEGER DEFAULT 0,
  
  -- Stripe info
  stripe_customer_id VARCHAR(255) UNIQUE,
  stripe_subscription_id VARCHAR(255),
  
  -- Metadata
  onboarding_completed BOOLEAN DEFAULT FALSE,
  last_login_at TIMESTAMP WITH TIME ZONE,
  trial_ends_at TIMESTAMP WITH TIME ZONE,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Indexes
  CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Generated content avec analytics
CREATE TABLE IF NOT EXISTS generated_content (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  
  -- Content info
  content_type VARCHAR(20) NOT NULL CHECK (content_type IN ('annonce', 'social', 'email')),
  content TEXT NOT NULL,
  title VARCHAR(500),
  
  -- Input data
  input_data JSONB NOT NULL,
  
  -- Metadata
  metadata JSONB DEFAULT '{}',
  
  -- Analytics
  views INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  
  -- Status
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT content_length_check CHECK (char_length(content) <= 50000)
);

-- ============================================
-- TABLES DE MONITORING ET ANALYTICS
-- ============================================

-- Error logs
CREATE TABLE IF NOT EXISTS error_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  error_message TEXT NOT NULL,
  error_stack TEXT,
  context JSONB DEFAULT '{}',
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  severity VARCHAR(20) DEFAULT 'error' CHECK (severity IN ('error', 'warning', 'info')),
  resolved BOOLEAN DEFAULT FALSE,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Performance logs
CREATE TABLE IF NOT EXISTS performance_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation VARCHAR(100) NOT NULL,
  duration INTEGER NOT NULL, -- en millisecondes
  metadata JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User activity logs
CREATE TABLE IF NOT EXISTS user_activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  action VARCHAR(100) NOT NULL,
  metadata JSONB DEFAULT '{}',
  ip_address INET,
  user_agent TEXT,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email logs
CREATE TABLE IF NOT EXISTS email_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('sent', 'failed', 'bounced', 'delivered')),
  resend_id VARCHAR(255),
  error TEXT,
  metadata JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Content analytics
CREATE TABLE IF NOT EXISTS content_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  content_type VARCHAR(20) NOT NULL,
  metadata JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Engagement analytics
CREATE TABLE IF NOT EXISTS engagement_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  action VARCHAR(100) NOT NULL,
  metadata JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversion analytics
CREATE TABLE IF NOT EXISTS conversion_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  event VARCHAR(50) NOT NULL CHECK (event IN ('signup', 'trial_start', 'subscription', 'churn')),
  metadata JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Health checks
CREATE TABLE IF NOT EXISTS health_checks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  database BOOLEAN NOT NULL,
  openai BOOLEAN NOT NULL,
  stripe BOOLEAN NOT NULL,
  email BOOLEAN NOT NULL,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- INDEXES POUR PERFORMANCE
-- ============================================

-- Users indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_subscription ON users(subscription_type, subscription_status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_stripe_customer ON users(stripe_customer_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Generated content indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_user_created ON generated_content(user_id, created_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_type ON generated_content(content_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_status ON generated_content(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_search ON generated_content USING gin(to_tsvector('french', title || ' ' || content));

-- Analytics indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_content_analytics_user_time ON content_analytics(user_id, timestamp DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_engagement_analytics_user_time ON engagement_analytics(user_id, timestamp DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_conversion_analytics_event_time ON conversion_analytics(event, timestamp DESC);

-- Logs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_error_logs_timestamp ON error_logs(timestamp DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_error_logs_severity ON error_logs(severity, resolved);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_performance_logs_operation ON performance_logs(operation, timestamp DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_activity_user_time ON user_activity_logs(user_id, timestamp DESC);

-- ============================================
-- FONCTIONS ET TRIGGERS
-- ============================================

-- Fonction pour incrémenter l'usage mensuel
CREATE OR REPLACE FUNCTION increment_monthly_usage(user_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE users 
  SET monthly_usage = monthly_usage + 1,
      updated_at = NOW()
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql;

-- Fonction pour reset l'usage mensuel
CREATE OR REPLACE FUNCTION reset_monthly_usage()
RETURNS void AS $$
BEGIN
  UPDATE users 
  SET monthly_usage = 0,
      updated_at = NOW()
  WHERE DATE_TRUNC('month', updated_at) < DATE_TRUNC('month', NOW());
END;
$$ LANGUAGE plpgsql;

-- Trigger pour updated_at automatique
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Appliquer le trigger aux tables principales
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_content_updated_at BEFORE UPDATE ON generated_content
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- VUES POUR ANALYTICS
-- ============================================

-- Vue des statistiques utilisateurs
CREATE OR REPLACE VIEW user_stats AS
SELECT 
  DATE_TRUNC('day', created_at) as date,
  COUNT(*) as daily_signups,
  COUNT(*) FILTER (WHERE subscription_type != 'free') as paid_signups,
  COUNT(*) FILTER (WHERE subscription_type = 'starter') as starter_signups,
  COUNT(*) FILTER (WHERE subscription_type = 'pro') as pro_signups,
  COUNT(*) FILTER (WHERE subscription_type = 'agence') as agence_signups
FROM users 
GROUP BY DATE_TRUNC('day', created_at)
ORDER BY date DESC;

-- Vue des métriques de contenu
CREATE OR REPLACE VIEW content_metrics AS
SELECT 
  DATE_TRUNC('day', created_at) as date,
  content_type,
  COUNT(*) as generations,
  COUNT(DISTINCT user_id) as unique_users,
  AVG(views) as avg_views,
  AVG(clicks) as avg_clicks
FROM generated_content
GROUP BY DATE_TRUNC('day', created_at), content_type
ORDER BY date DESC, content_type;

-- Vue des revenus (estimation)
CREATE OR REPLACE VIEW revenue_metrics AS
SELECT 
  DATE_TRUNC('month', created_at) as month,
  subscription_type,
  COUNT(*) as subscribers,
  CASE 
    WHEN subscription_type = 'starter' THEN COUNT(*) * 97
    WHEN subscription_type = 'pro' THEN COUNT(*) * 197
    WHEN subscription_type = 'agence' THEN COUNT(*) * 497
    ELSE 0
  END as estimated_mrr
FROM users
WHERE subscription_type != 'free'
GROUP BY DATE_TRUNC('month', created_at), subscription_type
ORDER BY month DESC, subscription_type;

-- ============================================
-- SÉCURITÉ ET PERMISSIONS
-- ============================================

-- RLS (Row Level Security) pour les données utilisateur
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE generated_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity_logs ENABLE ROW LEVEL SECURITY;

-- Politique pour que les utilisateurs ne voient que leurs données
CREATE POLICY "Users can view own data" ON users
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "Users can view own content" ON generated_content
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own activity" ON user_activity_logs
  FOR ALL USING (auth.uid() = user_id);

-- ============================================
-- MAINTENANCE ET CLEANUP
-- ============================================

-- Fonction de nettoyage des anciens logs
CREATE OR REPLACE FUNCTION cleanup_old_logs()
RETURNS void AS $$
BEGIN
  -- Supprimer les logs de performance > 30 jours
  DELETE FROM performance_logs 
  WHERE timestamp < NOW() - INTERVAL '30 days';
  
  -- Supprimer les logs d'activité > 90 jours
  DELETE FROM user_activity_logs 
  WHERE timestamp < NOW() - INTERVAL '90 days';
  
  -- Supprimer les logs d'erreurs résolues > 30 jours
  DELETE FROM error_logs 
  WHERE resolved = true AND timestamp < NOW() - INTERVAL '30 days';
  
  -- Archiver le contenu ancien des utilisateurs gratuits
  UPDATE generated_content 
  SET status = 'archived'
  WHERE created_at < NOW() - INTERVAL '1 year' 
  AND user_id IN (SELECT id FROM users WHERE subscription_type = 'free');
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- DONNÉES DE SEED POUR PRODUCTION
-- ============================================

-- Insérer des plans de base si ils n'existent pas
INSERT INTO users (id, email, name, subscription_type, content_limit) VALUES
  ('00000000-0000-0000-0000-000000000001', 'admin@immocontent.fr', 'Admin ImmoContent', 'agence', 999999)
ON CONFLICT (email) DO NOTHING;

-- Créer des index partiels pour optimiser les requêtes fréquentes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_active_users ON users(id) WHERE subscription_status = 'active';
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_recent_content ON generated_content(created_at DESC) WHERE created_at > NOW() - INTERVAL '30 days';

-- ============================================
-- COMMENTAIRES ET DOCUMENTATION
-- ============================================

COMMENT ON TABLE users IS 'Table principale des utilisateurs avec informations de subscription';
COMMENT ON TABLE generated_content IS 'Contenu généré par IA avec analytics intégrées';
COMMENT ON TABLE error_logs IS 'Logs d''erreurs pour monitoring et debugging';
COMMENT ON TABLE performance_logs IS 'Métriques de performance pour optimisation';
COMMENT ON TABLE content_analytics IS 'Analytics détaillées sur l''usage du contenu';

-- Fin du script
